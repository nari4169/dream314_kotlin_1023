package com.billcoreatech.dream314.ipgo;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.billcoreatech.dream314.R;
import com.billcoreatech.dream314.codeItem.CodeBean;
import com.billcoreatech.dream314.databinding.RepairitemBinding;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ChlgoRepairAdapter extends BaseAdapter {

    String TAG = "UserItemAdapter" ;
    ArrayList<CarRepairBean> carRepairArrayList ;
    LayoutInflater inflater;
    RepairitemBinding binding ;
    ArrayList<CodeBean> codeBeanArrayList ;
    Context context ;
    int nListCnt ;

    public ChlgoRepairAdapter(Context context, ArrayList<CarRepairBean> idata, ArrayList<CodeBean> idata2) {
        // 출고일자 기준 정렬이 필요하여
        Comparator<CarRepairBean> sortChlgoDt = new Comparator<CarRepairBean>() {
            @Override
            public int compare(CarRepairBean o1, CarRepairBean o2) {
                return o1.getChlgoDt().compareTo(o2.getChlgoDt()) * -1; // 역순정렬
            }
        };
        Collections.sort(idata, sortChlgoDt);
        this.carRepairArrayList = idata ;
        this.context = context ;
        this.inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        codeBeanArrayList = idata2 ;
    }

    @Override
    public int getCount() {
        return carRepairArrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return carRepairArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public void updateReceiptsList(ArrayList<CarRepairBean> _oData) {
        // 출고일자 기준 정렬이 필요하여
        Comparator<CarRepairBean> sortChlgoDt = new Comparator<CarRepairBean>() {
            @Override
            public int compare(CarRepairBean o1, CarRepairBean o2) {
                return o1.getChlgoDt().compareTo(o2.getChlgoDt()) * -1; // 역순정렬
            }
        };
        Collections.sort(_oData, sortChlgoDt);
        carRepairArrayList = _oData;
        nListCnt = carRepairArrayList.size(); // 배열 사이즈 다시 확인
        this.notifyDataSetChanged(); // 그냥 여기서 하자
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        binding = RepairitemBinding.inflate(inflater) ;
        CustomViewHolder holder ;
        if (convertView == null) {
            convertView = binding.getRoot() ;
            holder = new CustomViewHolder();
            for(int i = 0 ; i < codeBeanArrayList.size() ; i++) {
                switch (i) {
                    case 0: binding.txtBottom.setText(codeBeanArrayList.get(i).getPrvNm()); break ;
                    case 1: binding.txtOtMetal.setText(codeBeanArrayList.get(i).getPrvNm()); break ;
                    case 2: binding.txtPaint.setText(codeBeanArrayList.get(i).getPrvNm()); break ;
                    case 3: binding.txtAssembly.setText(codeBeanArrayList.get(i).getPrvNm()); break ;
                    case 4: binding.txtWorkOut.setText(codeBeanArrayList.get(i).getPrvNm()); break ;
                }
            }
            holder.txtCarType = binding.txtCarType ;
            holder.txtCarId = binding.txtCarId ;
            holder.txtIpgoDt = binding.txtIpgoDt ;
            holder.txtChlgoDt = binding.txtChlgoDt ;
            holder.txtBottom = binding.txtBottom ;
            holder.txtOtMetal = binding.txtOtMetal ;
            holder.txtPaint = binding.txtPaint ;
            holder.txtAssembly = binding.txtAssembly ;
            holder.txtWorkOut = binding.txtWorkOut ;
            convertView.setTag(holder) ;
        } else {
            holder = (CustomViewHolder) convertView.getTag();
        }
        holder.txtCarType.setText(carRepairArrayList.get(position).getCarType()) ;
        holder.txtCarId.setText(carRepairArrayList.get(position).getCarId());
        holder.txtIpgoDt.setText(carRepairArrayList.get(position).getIpgoDt()) ;
        holder.txtChlgoDt.setText(carRepairArrayList.get(position).getChlgoDt()) ;
        if ("Y".equals(carRepairArrayList.get(position).getRepairYn1())) {
            holder.txtBottom.setBackground(context.getDrawable(R.drawable.backgroud_yellow_100));
            holder.txtBottom.setTextColor(Color.WHITE);
        } else if ("C".equals(carRepairArrayList.get(position).getRepairYn1())) {
            holder.txtBottom.setBackground(context.getDrawable(R.drawable.backgroud_green_100));
            holder.txtBottom.setTextColor(Color.WHITE);
        } else if ("M".equals(carRepairArrayList.get(position).getRepairYn1())) {
            holder.txtBottom.setBackground(context.getDrawable(R.drawable.backgroud_yellowred_100));
            holder.txtBottom.setTextColor(Color.WHITE);
        } else {
            holder.txtBottom.setBackground(context.getDrawable(R.drawable.backgroud_border_100));
            holder.txtBottom.setTextColor(Color.BLACK);
        }
        if ("Y".equals(carRepairArrayList.get(position).getRepairYn2())) {
            holder.txtOtMetal.setBackground(context.getDrawable(R.drawable.backgroud_yellow_100));
            holder.txtOtMetal.setTextColor(Color.WHITE);
        } else if ("C".equals(carRepairArrayList.get(position).getRepairYn2())) {
            holder.txtOtMetal.setBackground(context.getDrawable(R.drawable.backgroud_green_100));
            holder.txtOtMetal.setTextColor(Color.WHITE);
        } else if ("M".equals(carRepairArrayList.get(position).getRepairYn2())) {
            holder.txtOtMetal.setBackground(context.getDrawable(R.drawable.backgroud_yellowred_100));
            holder.txtOtMetal.setTextColor(Color.WHITE);
        } else {
            holder.txtOtMetal.setBackground(context.getDrawable(R.drawable.backgroud_border_100));
            holder.txtOtMetal.setTextColor(Color.BLACK);
        }
        if ("Y".equals(carRepairArrayList.get(position).getRepairYn3())) {
            holder.txtPaint.setBackground(context.getDrawable(R.drawable.backgroud_yellow_100));
            holder.txtPaint.setTextColor(Color.WHITE);
        } else if ("C".equals(carRepairArrayList.get(position).getRepairYn3())) {
            holder.txtPaint.setBackground(context.getDrawable(R.drawable.backgroud_green_100));
            holder.txtPaint.setTextColor(Color.WHITE);
        } else if ("M".equals(carRepairArrayList.get(position).getRepairYn3())) {
            holder.txtPaint.setBackground(context.getDrawable(R.drawable.backgroud_yellowred_100));
            holder.txtPaint.setTextColor(Color.WHITE);
        } else {
            holder.txtPaint.setBackground(context.getDrawable(R.drawable.backgroud_border_100));
            holder.txtPaint.setTextColor(Color.BLACK);
        }
        if ("Y".equals(carRepairArrayList.get(position).getRepairYn4())) {
            holder.txtAssembly.setBackground(context.getDrawable(R.drawable.backgroud_yellow_100));
            holder.txtAssembly.setTextColor(Color.WHITE);
        } else if ("C".equals(carRepairArrayList.get(position).getRepairYn4())) {
            holder.txtAssembly.setBackground(context.getDrawable(R.drawable.backgroud_green_100));
            holder.txtAssembly.setTextColor(Color.WHITE);
        } else if ("M".equals(carRepairArrayList.get(position).getRepairYn4())) {
            holder.txtAssembly.setBackground(context.getDrawable(R.drawable.backgroud_yellowred_100));
            holder.txtAssembly.setTextColor(Color.WHITE);
        } else {
            holder.txtAssembly.setBackground(context.getDrawable(R.drawable.backgroud_border_100));
            holder.txtAssembly.setTextColor(Color.BLACK);
        }
        if ("Y".equals(carRepairArrayList.get(position).getRepairYn5())) {
            holder.txtWorkOut.setBackground(context.getDrawable(R.drawable.backgroud_yellow_100));
            holder.txtWorkOut.setTextColor(Color.WHITE);
        } else if ("C".equals(carRepairArrayList.get(position).getRepairYn5())) {
            holder.txtWorkOut.setBackground(context.getDrawable(R.drawable.backgroud_green_100));
            holder.txtWorkOut.setTextColor(Color.WHITE);
        } else if ("M".equals(carRepairArrayList.get(position).getRepairYn5())) {
            holder.txtWorkOut.setBackground(context.getDrawable(R.drawable.backgroud_yellowred_100));
            holder.txtWorkOut.setTextColor(Color.WHITE);
        } else {
            holder.txtWorkOut.setBackground(context.getDrawable(R.drawable.backgroud_border_100));
            holder.txtWorkOut.setTextColor(Color.BLACK);
        }
        if ("Y".equals(carRepairArrayList.get(position).getRepairCompleteYn())) {
            holder.txtChlgoDt.setBackground(context.getDrawable(R.drawable.backgroud_yellow_100));
            holder.txtChlgoDt.setTextColor(Color.WHITE);
        } else if ("C".equals(carRepairArrayList.get(position).getRepairCompleteYn())) {
            holder.txtChlgoDt.setBackground(context.getDrawable(R.drawable.backgroud_green_100));
            holder.txtChlgoDt.setTextColor(Color.WHITE);
        } else {
            holder.txtChlgoDt.setBackground(context.getDrawable(R.drawable.backgroud_border_100));
            holder.txtChlgoDt.setTextColor(Color.BLACK);
        }
        Log.i(TAG, "email=" + carRepairArrayList.get(position).getCarId()) ;
        return convertView;
    }

    public class CustomViewHolder {
        TextView txtCarType ;
        TextView txtCarId ;
        TextView txtIpgoDt ;
        TextView txtChlgoDt ;
        TextView txtBottom ;
        TextView txtOtMetal ;
        TextView txtPaint;
        TextView txtAssembly ;
        TextView txtWorkOut ;

    }
}
