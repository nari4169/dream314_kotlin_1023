package com.billcoreatech.dream314.codeItem;

public class CodeBean {

    String appCode ;
    String grpCd ;
    String prvCd ;
    String prvNm ;
    String useYn ;

    public void setAppCode(String appCode) {
        this.appCode = appCode;
    }

    public String getAppCode() {
        return appCode;
    }

    public void setGrpCd(String grpCd) {
        this.grpCd = grpCd;
    }

    public String getGrpCd() {
        return grpCd;
    }

    public void setPrvCd(String prvCd) {
        this.prvCd = prvCd;
    }

    public String getPrvCd() {
        return prvCd;
    }

    public void setPrvNm(String prvNm) {
        this.prvNm = prvNm;
    }

    public String getPrvNm() {
        return prvNm;
    }

    public void setUseYn(String useYn) {
        this.useYn = useYn;
    }

    public String getUseYn() {
        return useYn;
    }

}
