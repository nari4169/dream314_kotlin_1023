package com.billcoreatech.dream314.dataBase;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * 데이터 구조체 선언
 */
public class DBHelper extends SQLiteOpenHelper {

	private static final String DB_NAME = "safeDB" ;
	private static final int DB_Ver = 1 ; //
	String TAG = DB_NAME + ":";

	public DBHelper(Context context) {
		super(context, DB_NAME, null, DB_Ver);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		String sql = "create table codeItem (" +
				"_id integer primary key autoincrement, " +
				"grp_cd text," + // 그룹코드
				"prv_cd text," + // 세부코드
				"prv_nm text," + // 코드명
				"use_yn text" +       // 사용여부
			")";
		db.execSQL(sql) ;
	}

	/**
	 * @param db
	 * @param oldVersion
	 * @param newVersion
	 */
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		/* 삭제하면 안됨.
		db.execSQL("drop table if exists UploadImageList") ;
		onCreate(db) ;
		*/
		switch (newVersion) {

			default:

				Log.e(TAG, "default=" + oldVersion + "/" + newVersion ) ;

				break ;
		}
		Log.e(TAG, "onUpgrade end=" + oldVersion + "/" + newVersion ) ;

	}
	
}
