package com.billcoreatech.dream314.ipgo;

import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.billcoreatech.dream314.R;
import com.billcoreatech.dream314.codeItem.CodeBean;
import com.billcoreatech.dream314.databinding.ActivityChlgoBinding;
import com.billcoreatech.dream314.util.StringUtil;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ChlgoActivity extends AppCompatActivity {

    String TAG = "ChlgoActivity" ;
    ActivityChlgoBinding binding ;
    DatabaseReference mDatabase;
    DatabaseReference codeItem;
    ArrayList<CodeBean> codeBeanArrayList ;
    ArrayList<CarRepairBean> carRepairBeanArrayList ;
    ChlgoRepairAdapter adapter ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityChlgoBinding.inflate(getLayoutInflater());
        View view = binding.getRoot() ;
        setContentView(view);

        carRepairBeanArrayList = new ArrayList<>();
        codeBeanArrayList = new ArrayList<>();

        mDatabase = FirebaseDatabase.getInstance().getReference(StringUtil.getAppCode(getApplicationContext()) + "carRepair");
        codeItem = FirebaseDatabase.getInstance().getReference(StringUtil.getAppCode(getApplicationContext()) + "codeItem");

        getDisplayData() ;

        binding.btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        binding.btnFInd2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText edCarId = new EditText(ChlgoActivity.this);
                edCarId.setSingleLine(true);
                AlertDialog.Builder builder = new AlertDialog.Builder(ChlgoActivity.this);
                builder.setTitle(getString(R.string.find))
                        .setMessage(getString(R.string.msgFindCarId))
                        .setView(edCarId)
                        .setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                onFindCarId(edCarId.getText().toString()) ;
                            }
                        })
                        .setNegativeButton(getString(R.string.close), null);
                AlertDialog dialog = builder.create();
                dialog.show();
                dialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(Color.BLUE);
                dialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(Color.GRAY);
            }
        });
    }

    private void onFindCarId(String pCarID) {

        binding.baseProgressBar.setVisibility(View.VISIBLE);
        mDatabase.orderByChild("carId").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                carRepairBeanArrayList.clear();
                for(DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    try {
                        if (dataSnapshot.getValue(CarRepairBean.class).getCarId().contains(pCarID)) {
                            if ("C".equals(dataSnapshot.getValue(CarRepairBean.class).getRepairCompleteYn())) {
                                carRepairBeanArrayList.add(dataSnapshot.getValue(CarRepairBean.class));
                                Log.i(TAG, "carId=" + dataSnapshot.getValue(CarRepairBean.class).getCarId());
                            }
                        }
                    } catch (Exception e) {

                    }
                }
                adapter = new ChlgoRepairAdapter(getApplicationContext(), carRepairBeanArrayList, codeBeanArrayList) ;
                adapter.updateReceiptsList(carRepairBeanArrayList);
                binding.repairList.setAdapter(adapter);
                binding.baseProgressBar.setVisibility(View.GONE);
                Toast.makeText(getApplicationContext(), getString(R.string.msgFindCompleted), Toast.LENGTH_LONG).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        }) ;

    }

    private void getDisplayData() {

        binding.baseProgressBar.setVisibility(View.VISIBLE);
        codeItem.orderByChild("useYn").equalTo("Y").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int i = 0 ;
                codeBeanArrayList.clear();
                for(DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    codeBeanArrayList.add(dataSnapshot.getValue(CodeBean.class));
                }
                binding.baseProgressBar.setVisibility(View.GONE);

                binding.baseProgressBar.setVisibility(View.VISIBLE);
                mDatabase.orderByChild("repairCompleteYn").equalTo("C").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        carRepairBeanArrayList.clear();
                        for(DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            carRepairBeanArrayList.add(dataSnapshot.getValue(CarRepairBean.class));
                            Log.i(TAG, "carId=" + dataSnapshot.getValue(CarRepairBean.class).getCarId());
                        }
                        adapter = new ChlgoRepairAdapter(getApplicationContext(), carRepairBeanArrayList, codeBeanArrayList) ;
                        adapter.updateReceiptsList(carRepairBeanArrayList);
                        binding.repairList.setAdapter(adapter);
                        binding.baseProgressBar.setVisibility(View.GONE);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                }) ;
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        }) ;
    }
}