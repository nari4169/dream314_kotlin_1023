package com.billcoreatech.dream314.dataBase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

/**
 * 데이터 읽고, 쓰고, 갱신하고
 */
public class DBHandler {

	private DBHelper helper;
	private SQLiteDatabase db;

	String TAG = "DBHandler" ;
	
	public DBHandler(Context ctx) {
		helper = new DBHelper(ctx);
		db = helper.getWritableDatabase(); 
	}
	public static DBHandler open(Context ctx) throws SQLException {
		DBHandler handler = new DBHandler(ctx);
		return handler;
	}
	
	public void close(){
		helper.close();
	}

	public Cursor selectCode(String grpCd) {
		StringBuffer sb = new StringBuffer() ;
		sb.append(" select _id, grp_cd, prv_cd, prv_nm, use_yn ");
		sb.append(" from codeItem ");
		if (!"".equals(grpCd)) {
			sb.append(" where grp_cd = '" + grpCd + "' ");
		}
		sb.append(" order by prv_cd ") ;
		Cursor cursor = db.rawQuery(sb.toString(), null) ;
		return cursor ;
	}

	public long insertCode(String grpCd, String prvCd, String prvNm) {
		long result = 0 ;

		ContentValues values = new ContentValues();
		values.put("grp_cd", grpCd);
		values.put("prv_cd", prvCd);
		values.put("prv_nm", prvNm);
		values.put("use_yn", "Y") ;

		result = db.insert("codeItem", null, values);
		Log.i(TAG, "insertCode cnt=" + result + ":" + prvCd);

		return result ;
	}

	public long updateCode(String grpCd, String prvCd, String prvNm) {
		long result = 0 ;

		ContentValues values = new ContentValues();
		values.put("prv_nm", prvNm);
		values.put("use_yn", "Y") ;

		result = db.update("codeItem", values, "grp_cd = '" + grpCd + "' and prv_cd = '" + prvCd + "' ", null);
		Log.i(TAG, "updateCode cnt=" + result + ":" + prvCd);

		return result ;
	}

	public long deleteCode(String grpCd, String prvCd) {
		long result = 0 ;
		result = db.delete("codeItem", "grp_cd = '" + grpCd + "' and prv_cd = '" + prvCd + "' ", null);
		Log.i(TAG, "deleteCode cnt=" + result + ":" + prvCd);
		return result ;
	}

}
