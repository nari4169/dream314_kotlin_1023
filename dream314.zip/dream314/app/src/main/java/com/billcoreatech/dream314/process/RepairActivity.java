package com.billcoreatech.dream314.process;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.billcoreatech.dream314.R;
import com.billcoreatech.dream314.codeItem.CodeBean;
import com.billcoreatech.dream314.databinding.ActivityRepairBinding;
import com.billcoreatech.dream314.ipgo.CarRepairBean;
import com.billcoreatech.dream314.userManager.UserBean;
import com.billcoreatech.dream314.util.StringUtil;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class RepairActivity extends AppCompatActivity {

    String TAG = "RepairActivity" ;
    ActivityRepairBinding binding ;
    DatabaseReference mDatabase;
    DatabaseReference codeItem ;
    DatabaseReference carRepair ;
    DatabaseReference repairWork ;
    ArrayList<CodeBean> codeBeanArrayList ;
    ArrayList<RepairBean> repairWorkArrayList ;
    ArrayList<String> spItem ;
    RepairWorkAdapter adapter ;
    String userEmail ;
    String deptCode ;
    String deptCode1 ;
    int deptIndex ;
    int repairDeptCnt ;
    String repairYn = "repairYn1";
    boolean isComplete = false ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRepairBinding.inflate(getLayoutInflater());
        View view = binding.getRoot() ;
        setContentView(view);
        Intent intent = getIntent() ;
        userEmail = intent.getStringExtra("userEmail");

        codeBeanArrayList = new ArrayList<>();
        repairWorkArrayList = new ArrayList<>();
        spItem = new ArrayList<>() ;

        mDatabase = FirebaseDatabase.getInstance().getReference(StringUtil.getAppCode(getApplicationContext()) + "users");
        codeItem = FirebaseDatabase.getInstance().getReference(StringUtil.getAppCode(getApplicationContext()) + "codeItem");
        carRepair = FirebaseDatabase.getInstance().getReference(StringUtil.getAppCode(getApplicationContext()) + "carRepair");
        repairWork = FirebaseDatabase.getInstance().getReference(StringUtil.getAppCode(getApplicationContext()) + "repairWork");

        getUserInfo(userEmail);
        Log.i(TAG, "CurrentDate=" + getDateTime());

        binding.txtRepairTitle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isComplete = !isComplete ;
                if (isComplete) {
                    binding.txtRepairTitle.setBackground(getDrawable(R.drawable.backgroud_green_100));
                    binding.txtRepairTitle.setTextColor(Color.WHITE);
                } else {
                    binding.txtRepairTitle.setBackground(getDrawable(R.drawable.backgroud_grey_500));
                    binding.txtRepairTitle.setTextColor(Color.BLACK);
                }
                getCarRepair("", deptIndex) ;
            }
        });

        binding.btnClose2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        binding.spWorkDept.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Log.i(TAG, binding.spWorkDept.getItemAtPosition(position).toString());
                for(int i=0; i < codeBeanArrayList.size() ; i++) {
                    if(binding.spWorkDept.getItemAtPosition(position).toString().equals(codeBeanArrayList.get(i).getPrvNm())) {
                        deptIndex = i;
                        deptCode = codeBeanArrayList.get(i).getPrvCd() ;
                        break ;
                    }
                }
                getCarRepair("", deptIndex) ;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        binding.btnFind2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText edCarId = new EditText(RepairActivity.this);
                edCarId.setSingleLine(true);
                AlertDialog.Builder builder = new AlertDialog.Builder(RepairActivity.this);
                builder.setTitle(getString(R.string.find))
                        .setMessage(getString(R.string.msgFindCarId))
                        .setView(edCarId)
                        .setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                getCarRepair(edCarId.getText().toString(), deptIndex) ;
                            }
                        })
                        .setNegativeButton(getString(R.string.close), null);
                AlertDialog dialog = builder.create();
                dialog.show();
                dialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(Color.BLUE);
                dialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(Color.GRAY);
            }
        });

        binding.repairList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.i(TAG, "선택한 사용자=" + repairWorkArrayList.get(position).getUserId() + "<>" + binding.txtUserNm.getText().toString());
                if (repairWorkArrayList.get(position).getUserId() != null && !binding.txtUserNm.getText().toString().equals(repairWorkArrayList.get(position).getUserId())) {
                    Toast.makeText(getApplicationContext(), getString(R.string.msgOthersUserJob), Toast.LENGTH_LONG).show();
                }
                if (!"C".equals(repairWorkArrayList.get(position).getRepairStat())) {
                    String msgWorkProcess = "";
                    if ("M".equals(repairWorkArrayList.get(position).getRepairStat())) {
                        msgWorkProcess = getString(R.string.msgWorkOut) + "\n(" + getString(R.string.jobUserName) + ":" + repairWorkArrayList.get(position).getUserId() + ")";
                    } else {
                        // msgWorkProcess = getString(R.string.msgWorkReay);
                        msgWorkProcess = getString(R.string.msgWorkStart);
                    }
                    AlertDialog.Builder builder = new AlertDialog.Builder(RepairActivity.this);
                    builder.setTitle(getString(R.string.repairWork))
                            .setMessage(msgWorkProcess)
                            .setPositiveButton(getString(R.string.nextStep), new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    RepairBean repairBean = repairWorkArrayList.get(position);
                                    if ("M".equals(repairWorkArrayList.get(position).getRepairStat())) {
                                        repairBean.setRepairStat("C");
                                        Log.i(TAG, "C today=" + getDateTime());
                                        repairBean.setEndDt(getDateTime());
                                        carRepair.child(repairWorkArrayList.get(position).getCarId()).child(repairYn).setValue("C");
                                    } else {
                                        repairBean.setRepairStat("M");
                                        Log.i(TAG, "M today=" + getDateTime());
                                        repairBean.setStartDt(getDateTime());
                                        carRepair.child(repairWorkArrayList.get(position).getCarId()).child(repairYn).setValue("M");
                                    }
                                    repairBean.setUserId(binding.txtUserNm.getText().toString());
                                    repairWork.child(repairWorkArrayList.get(position).getDeptCode()
                                            + repairWorkArrayList.get(position).getCarId()).setValue(repairBean)
                                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {
                                                    Log.i(TAG, "onComplete ... ") ;
                                                }
                                            });
                                    chkRepairCompleted(repairBean.getCarId()) ;
                                    getCarRepair("", deptIndex);
                                }
                            })
                            .setNeutralButton(getString(R.string.close), null);
                    AlertDialog dialog = builder.create();
                    dialog.show();
                    dialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(Color.BLUE);
                    dialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(Color.GRAY);
                } else {
                    Toast.makeText(getApplicationContext(), getString(R.string.msgWorkCompleted), Toast.LENGTH_LONG).show();
                    AlertDialog.Builder builder = new AlertDialog.Builder(RepairActivity.this);
                    builder.setTitle(getString(R.string.repairInit))
                            .setMessage(getString(R.string.msgRepairInit))
                            .setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    repairWork.child(repairWorkArrayList.get(position).getDeptCode()
                                            + repairWorkArrayList.get(position).getCarId()).removeValue()
                                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {
                                                    Log.i(TAG, "onComplete ... ") ;
                                                }
                                            });
                                    getCarRepair("", deptIndex);
                                }
                            })
                            .setNegativeButton(getString(R.string.close), null);
                    AlertDialog dialog = builder.create() ;
                    dialog.show();
                    dialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(Color.RED);
                    dialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(Color.GRAY);

                }
            }
        });
    }


    /**
     * 현재 시간을 돌려 준다.
     * @return
     */
    private String getDateTime() {
        long now = System.currentTimeMillis() ;
        Date date = new Date(now);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        Log.i(TAG, "getDateTime=" + sdf.format(date)) ;
        return sdf.format(date);
    }

    /**
     * 로그인 사용자의 부서 코드를 기준으로 작업 대상 리스트를 찾기 위해서 로그인 사용자의 부서정보 확인
     * @param userEmail
     */
    private void getUserInfo(String userEmail) {
        binding.baseProgressBar.setVisibility(View.VISIBLE);
        mDatabase.orderByChild("userEmail").equalTo(userEmail).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    binding.txtUserNm.setText(dataSnapshot.getValue(UserBean.class).getUserName());
                    if (dataSnapshot.getValue(UserBean.class).getUserDept1() != null) {
                        binding.txtDeptNm.setText(dataSnapshot.getValue(UserBean.class).getUserDept() + "/" + dataSnapshot.getValue(UserBean.class).getUserDept1());
                    } else {
                        binding.txtDeptNm.setText(dataSnapshot.getValue(UserBean.class).getUserDept());
                    }
                    deptCode = dataSnapshot.getValue(UserBean.class).getDeptCode() ;
                    if (dataSnapshot.getValue(UserBean.class).getDeptCode1() != null) {
                        deptCode1 = dataSnapshot.getValue(UserBean.class).getDeptCode1() ;
                    } else {
                        deptCode1 = "" ;
                    }
                    Log.i(TAG, "deptCode=" + deptCode);
                    getCodeItem();
                }
                binding.baseProgressBar.setVisibility(View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    /**
     * 부서 코드가 뭔지 모르지만 순서대로 정리를 위한 키값 찾기
     */
    private void getCodeItem() {
        binding.baseProgressBar.setVisibility(View.VISIBLE);
        codeItem.orderByChild("useYn").equalTo("Y").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                codeBeanArrayList.clear();
                spItem.clear();
                int i = 0 ;
                for(DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    codeBeanArrayList.add(dataSnapshot.getValue(CodeBean.class));
                    Log.i(TAG, deptCode + "=" + dataSnapshot.getValue(CodeBean.class).getPrvCd()) ;
                    if (deptCode.equals(dataSnapshot.getValue(CodeBean.class).getPrvCd())) {
                        deptIndex = i ;
                        spItem.add(dataSnapshot.getValue(CodeBean.class).getPrvNm());
                    }
                    if (deptCode1.equals(dataSnapshot.getValue(CodeBean.class).getPrvCd())) {
                        spItem.add(dataSnapshot.getValue(CodeBean.class).getPrvNm());
                    }
                    i++;
                }
                repairDeptCnt = i ;
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(RepairActivity.this,
                        android.R.layout.simple_spinner_item, spItem);
                binding.spWorkDept.setAdapter(adapter);
                Log.i(TAG, "deptIndex=" + deptIndex + " repairDeptCnt=" + repairDeptCnt) ;
                binding.baseProgressBar.setVisibility(View.GONE);
                getCarRepair("", deptIndex) ;
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        }) ;
    }

    /**
     * 부서별로 조회가 되어야 하고, 검색기능을 만들어서 검색 조건도 적용을 할 수 있어야 함.
     * @param pCarId
     * @param deptIndex
     */
    public void getCarRepair(String pCarId, int deptIndex) {
        Log.i(TAG, "pCarId[" + pCarId + "] deptIndex[" + deptIndex + "]" + " deptCode[" + deptCode + "]") ;
        binding.baseProgressBar.setVisibility(View.VISIBLE);
        switch(deptIndex) {
            case 0: repairYn = "repairYn1" ; break;
            case 1: repairYn = "repairYn2" ; break;
            case 2: repairYn = "repairYn3" ; break;
            case 3: repairYn = "repairYn4" ; break;
            case 4: repairYn = "repairYn5" ; break;
            case 5: repairYn = "repairYn6" ; break;
            case 6: repairYn = "repairYn7" ; break;
            case 7: repairYn = "repairYn8" ; break;
            case 8: repairYn = "repairYn9" ; break;
        }
        carRepair.orderByChild(repairYn).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                repairWorkArrayList.clear();
                for(DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    CarRepairBean carRepairBean = dataSnapshot.getValue(CarRepairBean.class);
                    if (carRepairBean.getCarId().contains(pCarId)) {
                        if (isThisDeptJob(carRepairBean, deptIndex)) {
                            /**
                             * 시작할 떄 접수된 수 만큼 작업이 되었다면 완료된 작업을 설정 한다.
                             */
                            if (carRepairBean.getRepairCnt() == getRepairCompletedCnt(carRepairBean)) {
                                carRepair.child(carRepairBean.getCarId()).child("repairCompleteYn").setValue("C");
                                carRepairBean.setRepairCompleteYn("C");
                            }
                            RepairBean repairBean = new RepairBean();
                            repairBean.setDeptCode(deptCode);
                            repairBean.setCarType(dataSnapshot.getValue(CarRepairBean.class).getCarType());
                            repairBean.setCarId(dataSnapshot.getValue(CarRepairBean.class).getCarId());
                            repairBean.setChlgoDt(dataSnapshot.getValue(CarRepairBean.class).getChlgoDt());
                            binding.baseProgressBar.setVisibility(View.VISIBLE);
                            repairWork.orderByKey().equalTo(deptCode + repairBean.getCarId()).addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    for (DataSnapshot dataSnapshot1 : snapshot.getChildren()) {
                                        repairBean.setUserId(dataSnapshot1.getValue(RepairBean.class).getUserId());
                                        repairBean.setStartDt(dataSnapshot1.getValue(RepairBean.class).getStartDt());
                                        repairBean.setEndDt(dataSnapshot1.getValue(RepairBean.class).getEndDt());
                                        repairBean.setRepairStat(dataSnapshot1.getValue(RepairBean.class).getRepairStat());
                                        Log.i(TAG, "getStartDt=" + repairBean.getStartDt());
                                        Log.i(TAG, "getEndDt=" + repairBean.getEndDt());
                                        Log.i(TAG, "getRepairStat=" + repairBean.getRepairStat());
                                        adapter.updateReceiptsList(repairWorkArrayList);
                                        binding.baseProgressBar.setVisibility(View.GONE);
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {
                                    repairBean.setRepairStat("S");
                                    binding.baseProgressBar.setVisibility(View.GONE);
                                }
                            });
                            repairWorkArrayList.add(repairBean);
                            Log.i(TAG, codeBeanArrayList.get(deptIndex).getPrvNm() + "=" + dataSnapshot.getValue(CarRepairBean.class).getCarId());
                        }
                    }
                }
                adapter = new RepairWorkAdapter(getApplicationContext(), repairWorkArrayList);
                adapter.updateReceiptsList(repairWorkArrayList);
                binding.repairList.setAdapter(adapter);
                binding.baseProgressBar.setVisibility(View.GONE);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        }); ;
    }

    private boolean isThisDeptJob(CarRepairBean carRepairBean, int deptIndex) {
        boolean bResult = false ;
        if (isComplete) {
            switch (deptIndex) {
                case 0:
                    if ("C".equals(carRepairBean.getRepairYn1()) )
                        bResult = true;
                    break;
                case 1:
                    if ("C".equals(carRepairBean.getRepairYn2()) )
                        bResult = true;
                    break;
                case 2:
                    if ("C".equals(carRepairBean.getRepairYn3()) )
                        bResult = true;
                    break;
                case 3:
                    if ("C".equals(carRepairBean.getRepairYn4()) )
                        bResult = true;
                    break;
                case 4:
                    if ("C".equals(carRepairBean.getRepairYn5()) )
                        bResult = true;
                    break;
                case 5:
                    if ("C".equals(carRepairBean.getRepairYn6()) )
                        bResult = true;
                    break;
                case 6:
                    if ("C".equals(carRepairBean.getRepairYn7()) )
                        bResult = true;
                    break;
                case 7:
                    if ("C".equals(carRepairBean.getRepairYn8()) )
                        bResult = true;
                    break;
                case 8:
                    if ("C".equals(carRepairBean.getRepairYn9()) )
                        bResult = true;
                    break;
            }

        } else {
            switch (deptIndex) {
                case 0:
                    if ("Y".equals(carRepairBean.getRepairYn1()) || "M".equals(carRepairBean.getRepairYn1()))
                        bResult = true;
                    break;
                case 1:
                    if ("Y".equals(carRepairBean.getRepairYn2()) || "M".equals(carRepairBean.getRepairYn2()))
                        bResult = true;
                    break;
                case 2:
                    if ("Y".equals(carRepairBean.getRepairYn3()) || "M".equals(carRepairBean.getRepairYn3()))
                        bResult = true;
                    break;
                case 3:
                    if ("Y".equals(carRepairBean.getRepairYn4()) || "M".equals(carRepairBean.getRepairYn4()))
                        bResult = true;
                    break;
                case 4:
                    if ("Y".equals(carRepairBean.getRepairYn5()) || "M".equals(carRepairBean.getRepairYn5()))
                        bResult = true;
                    break;
                case 5:
                    if ("Y".equals(carRepairBean.getRepairYn6()) || "M".equals(carRepairBean.getRepairYn6()))
                        bResult = true;
                    break;
                case 6:
                    if ("Y".equals(carRepairBean.getRepairYn7()) || "M".equals(carRepairBean.getRepairYn7()))
                        bResult = true;
                    break;
                case 7:
                    if ("Y".equals(carRepairBean.getRepairYn8()) || "M".equals(carRepairBean.getRepairYn8()))
                        bResult = true;
                    break;
                case 8:
                    if ("Y".equals(carRepairBean.getRepairYn9()) || "M".equals(carRepairBean.getRepairYn9()))
                        bResult = true;
                    break;
            }
        }
        return bResult ;
    }

    private void chkRepairCompleted(String carId) {
        carRepair.orderByKey().equalTo(carId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    CarRepairBean carRepairBean = dataSnapshot.getValue(CarRepairBean.class);
                    Log.i(TAG, "completed check=" + carRepairBean.getCarId()) ;
                    if (carRepairBean.getRepairCnt() == getRepairCompletedCnt(carRepairBean)) {
                        carRepair.child(carRepairBean.getCarId()).child("repairCompleteYn").setValue("C")
                                 .addOnSuccessListener(new OnSuccessListener<Void>() {
                                     @Override
                                     public void onSuccess(Void aVoid) {
                                         Log.i(TAG, "success onCompleted...") ;
                                     }
                                 });
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    /**
     * 수리가 완료된 작업의 수를 구함
     * @param carRepairBean
     * @return
     */
    private int getRepairCompletedCnt(CarRepairBean carRepairBean) {
        int iCnt = 0 ;
        if ("C".equals(carRepairBean.getRepairYn1())) {
            iCnt++;
        }
        if ("C".equals(carRepairBean.getRepairYn2())) {
            iCnt++;
        }
        if ("C".equals(carRepairBean.getRepairYn3())) {
            iCnt++;
        }
        if ("C".equals(carRepairBean.getRepairYn4())) {
            iCnt++;
        }
        if ("C".equals(carRepairBean.getRepairYn5())) {
            iCnt++;
        }
        if ("C".equals(carRepairBean.getRepairYn6())) {
            iCnt++;
        }
        if ("C".equals(carRepairBean.getRepairYn7())) {
            iCnt++;
        }
        if ("C".equals(carRepairBean.getRepairYn8())) {
            iCnt++;
        }
        if ("C".equals(carRepairBean.getRepairYn9())) {
            iCnt++;
        }
        return iCnt ;
    }
}