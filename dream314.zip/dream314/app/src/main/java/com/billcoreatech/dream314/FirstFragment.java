package com.billcoreatech.dream314;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.android.billingclient.api.SkuDetails;
import com.billcoreatech.dream314.billing.BillingManager;
import com.billcoreatech.dream314.billing.BillinguserBean;
import com.billcoreatech.dream314.databinding.AppuserinfoBinding;
import com.billcoreatech.dream314.databinding.FragmentFirstBinding;
import com.billcoreatech.dream314.userManager.UserBean;
import com.billcoreatech.dream314.util.GoogleSignInActivity;
import com.billcoreatech.dream314.util.StringUtil;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class FirstFragment extends Fragment {

    FirebaseAuth mAuth;
    FirebaseUser currentUser ;
    GoogleSignInClient mGoogleSignInClient;
    DatabaseReference userInfo;
    DatabaseReference userinfoDB;
    FragmentFirstBinding binding ;
    AppuserinfoBinding userinfoBinding ;
    String TAG = "FirstFragment" ;
    BillingManager billingManager ;
    Context context ;
    BillinguserBean billinguserBean;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        context = container.getContext() ;
        binding = FragmentFirstBinding.inflate(getLayoutInflater());
        View view = binding.getRoot() ;
        // Inflate the layout for this fragment
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        mGoogleSignInClient = GoogleSignIn.getClient(context, gso);
        billingManager = new BillingManager(getActivity());
        return view ; // inflater.inflate(R.layout.fragment_first, container, false);
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();
        userinfoDB = FirebaseDatabase.getInstance().getReference("UserInfoDB");
        userInfo = FirebaseDatabase.getInstance().getReference(StringUtil.getAppCode(context) + "users");
        billinguserBean = new BillinguserBean() ;
        Log.i(TAG, "===" + StringUtil.getAppDispName(context));

        binding.txtAppCode.setText(StringUtil.getAppDispName(context));
        dispUserName() ;
        binding.btnHelp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://billcorea.tistory.com/20"));
                startActivity(browserIntent);
            }
        });
        binding.initApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userinfoBinding = AppuserinfoBinding.inflate(getLayoutInflater());
                View userinfoView = userinfoBinding.getRoot();
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle(getString(R.string.appCode))
                        .setMessage(getString(R.string.msgEnterAppCode))
                        .setView(userinfoView)
                        .setPositiveButton(getString(R.string.OK), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Log.i(TAG, "appCode 사용자등록:" + userinfoBinding.editEmailAddress.getText().toString()) ;
                                StringUtil.setAppCode(context, userinfoBinding.editEmailAddress.getText().toString()
                                               , userinfoBinding.editOfficeName.getText().toString());
                                getActivity().finish();
                            }
                        }) ;
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        binding.btnManager.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), GoogleSignInActivity.class) ;
                intent.putExtra("mode", "managerLogin");
                startActivityForResult(intent, 0);

            }
        });

        binding.btnJoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getContext(), GoogleSignInActivity.class) ;
                intent.putExtra("mode", "memberJoin");
                startActivityForResult(intent, 0);
//                NavHostFragment.findNavController(FirstFragment.this)
//                        .navigate(R.id.action_FirstFragment_to_SecondFragment);
            }
        });

        binding.btnNewRepairAppend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), GoogleSignInActivity.class) ;
                intent.putExtra("mode", "newRepair");
                startActivityForResult(intent, 0);
            }
        });

        binding.btnCompletedList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), GoogleSignInActivity.class) ;
                intent.putExtra("mode", "CompletedList");
                startActivityForResult(intent, 0);
            }
        });

        binding.btnRepairDashboard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), GoogleSignInActivity.class) ;
                intent.putExtra("mode", "RepairDashboard");
                startActivityForResult(intent, 0);
            }
        });

        binding.btnRepairProcess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), GoogleSignInActivity.class) ;
                intent.putExtra("mode", "repairProcess");
                startActivityForResult(intent, 0);
            }
        });

        binding.btnSignOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signOut();
                getActivity().finish();
            }
        });

        binding.btnBill.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i(TAG, "clicked..." ) ;
                if(billingManager.connectStatus == BillingManager.connectStatusTypes.connected) {
                    Log.i(TAG, "connected ..") ;
                    SkuDetails skuDetails = (SkuDetails) billingManager.mSkuDetails.get(0);
                    int iResp = billingManager.purchase(skuDetails) ;
                    Log.i(TAG, "iResp=" + iResp) ;
                }
            }
        });
        //binding.btnBill.setVisibility(View.GONE);

    }

    @Override
    public void onStart() {
        super.onStart();
        Log.i(TAG, "onStart ........... " + StringUtil.getAppCode(context));
        dispUserName() ;
        userinfoDB.orderByKey().equalTo(StringUtil.getAppCode(context)).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot snapshot1 : snapshot.getChildren()) {
                    Log.i(TAG, "-----------------------------------------------------------------");
                    billinguserBean = snapshot1.getValue(BillinguserBean.class);
                    Log.i(TAG, "email=" + billinguserBean.getUserEmail()) ;
                    Log.i(TAG, "name=" + billinguserBean.getUserName()) ;
                    Log.i(TAG, "pDate=" + billinguserBean.getPurchaseDate()) ;
                    Log.i(TAG, "pTerm=" + billinguserBean.getPurchaseTerm()) ;
                    Log.i(TAG, "pStatus=" + billinguserBean.getPurchaseStatus()) ;
                    if (!StringUtil.isAgree(billinguserBean)) {
                        binding.btnBill.setVisibility(View.VISIBLE);
                        binding.btnManager.setVisibility(View.GONE);
                        binding.btnNewRepairAppend.setVisibility(View.GONE);
                    } else {
                        //binding.btnBill.setVisibility(View.GONE);
                        binding.btnManager.setVisibility(View.VISIBLE);
                        binding.btnNewRepairAppend.setVisibility(View.VISIBLE);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    @Override
    public void onAttachFragment(@NonNull Fragment childFragment) {
        super.onAttachFragment(childFragment);
        Log.i(TAG, "onAttachFragment ........... ");
        dispUserName() ;
    }

    private void dispUserName() {

        if (currentUser != null) {
            Log.i(TAG, "dispUserName email=" + currentUser.getEmail());
            userInfo.orderByChild("userEmail").equalTo(currentUser.getEmail()).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    for(DataSnapshot dataSnapshot : snapshot.getChildren()) {
                        if (dataSnapshot.getValue(UserBean.class).getUserDept1() != null && !"".equals(dataSnapshot.getValue(UserBean.class).getUserDept1())) {
                            binding.txtDeptNameMain.setText(dataSnapshot.getValue(UserBean.class).getUserDept() + "/" + dataSnapshot.getValue(UserBean.class).getUserDept1());
                        } else {
                            binding.txtDeptNameMain.setText(dataSnapshot.getValue(UserBean.class).getUserDept());
                        }
                        binding.txtUserNameMain.setText(dataSnapshot.getValue(UserBean.class).getUserName());
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.i(TAG, "onCancelled ........................... ") ;
                }
            });
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.i(TAG, "onActivityResult ........... ");
        dispUserName() ;
        if (requestCode == 0) {
            if (resultCode == 0) {

            }
        }
    }

    private void signOut() {
        // Firebase sign out
        mAuth.signOut();

        // Google sign out
        mGoogleSignInClient.signOut().addOnCompleteListener((Activity) context,
                new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        Toast.makeText(getContext(), getString(R.string.signed_out), Toast.LENGTH_LONG).show();
                    }
                });
    }
}