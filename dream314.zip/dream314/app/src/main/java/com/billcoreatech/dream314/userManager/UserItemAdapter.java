package com.billcoreatech.dream314.userManager;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.billcoreatech.dream314.databinding.UserbeanitemBinding;

import java.util.ArrayList;

public class UserItemAdapter extends BaseAdapter {

    String TAG = "UserItemAdapter" ;
    ArrayList<UserBean> userBeanArrayList ;
    LayoutInflater inflater;
    UserbeanitemBinding binding ;
    int nListCnt ;

    public  UserItemAdapter(Context context, ArrayList<UserBean> idata) {
        this.userBeanArrayList = idata ;
        this.inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return userBeanArrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return userBeanArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public void updateReceiptsList(ArrayList<UserBean> _oData) {
        userBeanArrayList = _oData;
        nListCnt = userBeanArrayList.size(); // 배열 사이즈 다시 확인
        this.notifyDataSetChanged(); // 그냥 여기서 하자
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        binding = UserbeanitemBinding.inflate(inflater) ;
        CustomViewHolder holder ;
        if (convertView == null) {
            convertView = binding.getRoot() ;
            holder = new CustomViewHolder();
            holder.txtEmailitem = binding.txtEmailitem ;
            holder.txtUserNameItem = binding.txtUserNameItem ;
            holder.txtDepItem = binding.txtDepItem ;
            holder.txtDepItem1 = binding.txtDepItem1 ;
            convertView.setTag(holder) ;
        } else {
            holder = (CustomViewHolder) convertView.getTag();
        }
        holder.txtEmailitem.setText(userBeanArrayList.get(position).getUserEmail()) ;
        holder.txtUserNameItem.setText(userBeanArrayList.get(position).getUserName());
        holder.txtDepItem.setText(String.valueOf(userBeanArrayList.get(position).getUserDept())) ;
        if (userBeanArrayList.get(position).getUserDept1() != null) {
            holder.txtDepItem1.setText(String.valueOf(userBeanArrayList.get(position).getUserDept1())) ;
        } else {
            holder.txtDepItem1.setText("");
        }
        if ("N".equals(userBeanArrayList.get(position).getUseYn())) {
            holder.txtEmailitem.setBackgroundColor(Color.GRAY);
            holder.txtUserNameItem.setBackgroundColor(Color.GRAY);
            holder.txtDepItem.setBackgroundColor(Color.GRAY);
            holder.txtDepItem1.setBackgroundColor(Color.GRAY);
        }
        return convertView;
    }

    public class CustomViewHolder {
        TextView txtEmailitem ;
        TextView txtUserNameItem ;
        TextView txtDepItem ;
        TextView txtDepItem1 ;

    }
}
