package com.billcoreatech.dream314.userManager;

import com.billcoreatech.dream314.util.StringUtil;

public class UserBean {

    String appCode ;
    String userEmail ;
    String userPassword ;
    String userName ;
    String userDept ;
    String userDept1 ;
    String deptCode ;
    String deptCode1 ;
    String masterTy ;
    String useYn ;

    public void Userbean() {

    }

    public void setAppCode(String appCode) {
        this.appCode = appCode;
    }

    public String getAppCode() {
        return appCode;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserPassword(String userPassword) {
        // 패스워드는 암호화해서 기록하기
        this.userPassword = StringUtil.makeSHA256(userPassword);
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserDept(String userDept) {
        this.userDept = userDept;
    }

    public String getUserDept() {
        return userDept;
    }

    public void setDeptCode(String deptCode) {
        this.deptCode = deptCode;
    }

    public String getDeptCode() {
        return deptCode;
    }

    public void setUserDept1(String userDept1) {
        this.userDept1 = userDept1;
    }

    public String getUserDept1() {
        return userDept1;
    }

    public void setDeptCode1(String deptCode1) {
        this.deptCode1 = deptCode1;
    }

    public String getDeptCode1() {
        return deptCode1;
    }
    public void setMasterTy(String masterTy) {
        this.masterTy = masterTy;
    }

    public String getMasterTy() {
        return masterTy;
    }

    public void setUseYn(String useYn) {
        this.useYn = useYn;
    }

    public String getUseYn() {
        return useYn;
    }
}
