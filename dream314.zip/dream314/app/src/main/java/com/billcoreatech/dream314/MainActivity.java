package com.billcoreatech.dream314;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.billcoreatech.dream314.billing.BillingManager;
import com.billcoreatech.dream314.billing.BillinguserBean;
import com.billcoreatech.dream314.databinding.ActivityMainBinding;
import com.billcoreatech.dream314.databinding.AppuserinfoBinding;
import com.billcoreatech.dream314.util.StringUtil;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import static android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding ;
    AppuserinfoBinding userinfoBinding ;
    SharedPreferences sp ;
    SharedPreferences.Editor editor ;
    String TAG = "MainActivity" ;
    private FirebaseAuth mAuth;
    BillinguserBean billinguserBean ;
    DatabaseReference userinfoDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater()) ;
        View view = binding.getRoot() ;
        setContentView(view);

        mAuth = FirebaseAuth.getInstance() ;
        userinfoDB = FirebaseDatabase.getInstance().getReference("UserInfoDB");

        sp = getSharedPreferences("appCode", MODE_PRIVATE);
        String appCode = sp.getString("appCode","A001");
        Log.i(TAG, "appCode=" + appCode);
        if ("A001".equals(appCode)) {
            userinfoBinding = AppuserinfoBinding.inflate(getLayoutInflater());
            View view1 = userinfoBinding.getRoot();
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle(getString(R.string.appCode))
                    .setMessage(getString(R.string.msgEnterAppCode))
                    .setView(view1)
                    .setPositiveButton(getString(R.string.OK), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Log.i(TAG, "appCode 사용자등록:" + userinfoBinding.editEmailAddress.getText().toString()) ;
                            if (userinfoBinding.editEmailAddress.getText().toString() != null && !"".equals(userinfoBinding.editEmailAddress.getText().toString())) {
                                mAuth.signInWithEmailAndPassword(userinfoBinding.editEmailAddress.getText().toString(), userinfoBinding.editEmailAddress.getText().toString())
                                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                            @Override
                                            public void onComplete(@NonNull Task<AuthResult> task) {
                                                Log.i(TAG, "----------------" ) ;
                                                if (task.isSuccessful()) {
                                                    Log.i(TAG, "appCode 등록이 되면...") ;
                                                    Toast.makeText(getApplicationContext(), getString(R.string.msgExistUser), Toast.LENGTH_LONG).show();
                                                    finish();

                                                } else {
                                                    Log.i(TAG, "appCode 등록이 안되면...") ;
                                                    mAuth.createUserWithEmailAndPassword(userinfoBinding.editEmailAddress.getText().toString(), userinfoBinding.editEmailAddress.getText().toString())
                                                            .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                                                @Override
                                                                public void onComplete(@NonNull Task<AuthResult> task) {
                                                                    if (task.isSuccessful()) {
                                                                        Log.i(TAG, "appCode 새로 등록 했다.");
                                                                        StringUtil.setAppCode(getApplicationContext(),
                                                                                userinfoBinding.editEmailAddress.getText().toString(),
                                                                                userinfoBinding.editOfficeName.getText().toString());

                                                                        billinguserBean = new BillinguserBean();
                                                                        billinguserBean.setUserEmail(userinfoBinding.editEmailAddress.getText().toString());
                                                                        billinguserBean.setUserName(userinfoBinding.editOfficeName.getText().toString());
                                                                        billinguserBean.setPurchaseDate("");
                                                                        billinguserBean.setPurchaseTerm("1");
                                                                        billinguserBean.setPurchaseStatus("9");
                                                                        userinfoDB.child(billinguserBean.getUserEmail().replaceAll("[^a-zA-Z0-9]","")+"_")
                                                                                .setValue(billinguserBean);

                                                                    } else {
                                                                        try {
                                                                            Log.i(TAG, "appCode 새로 등록 못해." + task.getResult().toString());
                                                                        } catch (Exception e) {
                                                                            Log.e(TAG, "Error " + e.toString()) ;
                                                                            Toast.makeText(getApplicationContext(), getString(R.string.msgExistUser), Toast.LENGTH_LONG).show();
                                                                            finish();
                                                                        }
                                                                    }
                                                                }
                                                            });
                                                }
                                            }
                                        });
                            } else {
                                Toast.makeText(getApplicationContext(), getString(R.string.msgEnterEmail), Toast.LENGTH_LONG).show();
                                finish();
                            }
                        }
                    }) ;
            AlertDialog dialog = builder.create();
            dialog.show();

        }
    }
}