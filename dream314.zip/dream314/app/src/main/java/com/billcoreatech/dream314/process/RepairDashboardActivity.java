package com.billcoreatech.dream314.process;

import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.billcoreatech.dream314.R;
import com.billcoreatech.dream314.codeItem.CodeBean;
import com.billcoreatech.dream314.databinding.ActivityRepairDashboardBinding;
import com.billcoreatech.dream314.util.StringUtil;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class RepairDashboardActivity extends AppCompatActivity {

    String TAG = "RepairDashboardActivity" ;
    ActivityRepairDashboardBinding binding ;
    DatabaseReference mDatabase;
    DatabaseReference codeItem ;
    DatabaseReference carRepair ;
    DatabaseReference repairWork ;
    ArrayList<CodeBean> codeBeanArrayList ;
    ArrayList<RepairBean> repairWorkArrayList ;
    RepairDashboardAdapter adapter ;
    boolean isComplete = false ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRepairDashboardBinding.inflate(getLayoutInflater()) ;
        View view = binding.getRoot() ;
        setContentView(view);

        codeBeanArrayList = new ArrayList<>();
        repairWorkArrayList = new ArrayList<>();

        mDatabase = FirebaseDatabase.getInstance().getReference(StringUtil.getAppCode(getApplicationContext()) + "users");
        codeItem = FirebaseDatabase.getInstance().getReference(StringUtil.getAppCode(getApplicationContext()) + "codeItem");
        carRepair = FirebaseDatabase.getInstance().getReference(StringUtil.getAppCode(getApplicationContext()) + "carRepair");
        repairWork = FirebaseDatabase.getInstance().getReference(StringUtil.getAppCode(getApplicationContext()) + "repairWork");

        getCodeItem();

        binding.txtRepairTitle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isComplete = !isComplete ;
                if (isComplete) {
                    binding.txtRepairTitle.setBackground(getDrawable(R.drawable.backgroud_green_100));
                    binding.txtRepairTitle.setTextColor(Color.WHITE);
                } else {
                    binding.txtRepairTitle.setBackground(getDrawable(R.drawable.backgroud_grey_500));
                    binding.txtRepairTitle.setTextColor(Color.BLACK);
                }
                getCarRepair("") ;
            }
        });

        binding.btnFind4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText edCarId = new EditText(RepairDashboardActivity.this);
                edCarId.setSingleLine(true);
                AlertDialog.Builder builder = new AlertDialog.Builder(RepairDashboardActivity.this);
                builder.setTitle(getString(R.string.find))
                        .setMessage(getString(R.string.msgFindCarId))
                        .setView(edCarId)
                        .setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                getCarRepair(edCarId.getText().toString()) ;
                            }
                        })
                        .setNegativeButton(getString(R.string.close), null);
                AlertDialog dialog = builder.create();
                dialog.show();
                dialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(Color.BLUE);
                dialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(Color.GRAY);
            }
        });

        binding.btnClose2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    /**
     * 부서 코드가 뭔지 모르지만 순서대로 정리를 위한 키값 찾기
     */
    private void getCodeItem() {
        binding.baseProgressBar.setVisibility(View.VISIBLE);
        codeItem.orderByChild("useYn").equalTo("Y").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                codeBeanArrayList.clear();
                for(DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    codeBeanArrayList.add(dataSnapshot.getValue(CodeBean.class));
                }
                binding.baseProgressBar.setVisibility(View.GONE);
                getCarRepair("") ;
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        }) ;
    }

    /**
     * 작업중인 리스트 조회
     */
    public void getCarRepair(String pCardId) {
        binding.baseProgressBar.setVisibility(View.VISIBLE);
        repairWork.orderByChild("deptCode").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                repairWorkArrayList.clear();
                for(DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    if (dataSnapshot.getValue(RepairBean.class).getCarId().contains(pCardId)) {
                        if (isComplete) {
                            if ("C".equals(dataSnapshot.getValue(RepairBean.class).getRepairStat())) {
                                repairWorkArrayList.add(dataSnapshot.getValue(RepairBean.class));
                            }
                        } else {
                            if (!"C".equals(dataSnapshot.getValue(RepairBean.class).getRepairStat())) {
                                repairWorkArrayList.add(dataSnapshot.getValue(RepairBean.class));
                            }
                        }
                    }
                }
                adapter = new RepairDashboardAdapter(getApplicationContext(), repairWorkArrayList, codeBeanArrayList);
                adapter.updateReceiptsList(repairWorkArrayList);
                binding.repairList.setAdapter(adapter);
                binding.baseProgressBar.setVisibility(View.GONE);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        }) ;
    }
}