package com.billcoreatech.dream314.process;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.billcoreatech.dream314.R;
import com.billcoreatech.dream314.databinding.RepairworkitemBinding;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class RepairWorkAdapter extends BaseAdapter {

    String TAG = "RepairWorkAdapter" ;
    ArrayList<RepairBean> repairWorkArrayList ;
    LayoutInflater inflater;
    RepairworkitemBinding binding ;
    Context context ;
    int nListCnt ;

    public  RepairWorkAdapter(Context context, ArrayList<RepairBean> idata) {
        // 출고일자 기준 정렬이 필요하여
        Comparator<RepairBean> sortChlgoDt = new Comparator<RepairBean>() {
            @Override
            public int compare(RepairBean o1, RepairBean o2) {
                return o1.getChlgoDt().compareTo(o2.getChlgoDt());
            }
        };
        Collections.sort(idata, sortChlgoDt);
        this.repairWorkArrayList = idata ;
        this.context = context ;
        this.inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return repairWorkArrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return repairWorkArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public void updateReceiptsList(ArrayList<RepairBean> _oData) {
        // 출고일자 기준 정렬이 필요하여
        Comparator<RepairBean> sortChlgoDt = new Comparator<RepairBean>() {
            @Override
            public int compare(RepairBean o1, RepairBean o2) {
                return o1.getChlgoDt().compareTo(o2.getChlgoDt());
            }
        };
        Collections.sort(_oData, sortChlgoDt);
        repairWorkArrayList = _oData;
        nListCnt = repairWorkArrayList.size(); // 배열 사이즈 다시 확인
        this.notifyDataSetChanged(); // 그냥 여기서 하자
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        binding = RepairworkitemBinding.inflate(inflater) ;
        CustomViewHolder holder ;
        if (convertView == null) {
            convertView = binding.getRoot() ;
            holder = new CustomViewHolder();
            holder.txtCarType = binding.txtCarType ;
            holder.txtCarId = binding.txtCarId ;
            holder.txtStartDt = binding.txtStartDt ;
            holder.txtEndDt = binding.txtEndDt ;
            holder.txtUserName = binding.txtUserName ;
            holder.txtWorkStatus = binding.txtWorkStatus ;
            convertView.setTag(holder) ;
        } else {
            holder = (CustomViewHolder) convertView.getTag();
        }
        holder.txtCarType.setText(repairWorkArrayList.get(position).getCarType()) ;
        holder.txtCarId.setText(repairWorkArrayList.get(position).getCarId());
        holder.txtStartDt.setText(repairWorkArrayList.get(position).getStartDt()) ;
        holder.txtEndDt.setText(repairWorkArrayList.get(position).getEndDt()) ;
        holder.txtUserName.setText(repairWorkArrayList.get(position).getUserId());
        if ("M".equals(repairWorkArrayList.get(position).getRepairStat())) {
            holder.txtWorkStatus.setText(context.getString(R.string.repairProcess));
        } else if ("C".equals(repairWorkArrayList.get(position).getRepairStat())) {
            holder.txtWorkStatus.setText(context.getString(R.string.repairCompleted));
        } else {
            holder.txtWorkStatus.setText(context.getString(R.string.repairStart));
        }

        // Log.i(TAG, "getCarId=" + repairWorkArrayList.get(position).getCarId()) ;
        return convertView;
    }

    public class CustomViewHolder {
        TextView txtCarType ;
        TextView txtCarId ;
        TextView txtStartDt ;
        TextView txtEndDt ;
        TextView txtUserName ;
        TextView txtWorkStatus ;
    }
}
