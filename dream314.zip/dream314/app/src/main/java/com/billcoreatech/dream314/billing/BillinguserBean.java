package com.billcoreatech.dream314.billing;

/**
 * 재구매 관리를 위한 데이터 구조체
 */
public class BillinguserBean {

    String userEmail ; // 사용자이메일
    String userName ;  // 화면에 표기할 이름
    String purchaseDate ; // 구매일자
    String purchaseTerm ; // 재구매주기
    String purchaseStatus ; // 구매상태
    String orderId ;
    String productId ;
    String purchaseToken ;
    boolean autoRenewing ;
    boolean acknowledged ;

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserName() {
        return userName;
    }

    public void setPurchaseDate(String purchaseDate) {
        this.purchaseDate = purchaseDate;
    }

    public String getPurchaseDate() {
        return purchaseDate;
    }

    public void setPurchaseTerm(String purchaseTerm) {
        this.purchaseTerm = purchaseTerm;
    }

    public String getPurchaseTerm() {
        return purchaseTerm;
    }

    public void setPurchaseStatus(String purchaseStatus) {
        this.purchaseStatus = purchaseStatus;
    }

    public String getPurchaseStatus() {
        return purchaseStatus;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductId() {
        return productId;
    }

    public void setPurchaseToken(String purchaseToken) {
        this.purchaseToken = purchaseToken;
    }

    public String getPurchaseToken() {
        return purchaseToken;
    }

    public void setAutoRenewing(boolean autoRenewing) {
        this.autoRenewing = autoRenewing;
    }

    public boolean isAutoRenewing() {
        return autoRenewing;
    }

    public void setAcknowledged(boolean acknowledged) {
        this.acknowledged = acknowledged;
    }

    public boolean isAcknowledged() {
        return acknowledged;
    }

}
