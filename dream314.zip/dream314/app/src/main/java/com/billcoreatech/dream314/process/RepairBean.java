package com.billcoreatech.dream314.process;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 부서별 작업관련 정보
 */
public class RepairBean {

    String appCode ;
    String deptCode ;
    String carType ;
    String carId ;
    String userId ;
    String repairStat ;
    String startDt ;
    String endDt ;
    String chlgoDt ;

    public void setAppCode(String appCode) {
        this.appCode = appCode;
    }

    public String getAppCode() {
        return appCode;
    }

    public void setDeptCode(String deptCode) {
        this.deptCode = deptCode;
    }

    public String getDeptCode() {
        return deptCode;
    }

    public void setCarType(String carType) {
        this.carType = carType;
    }

    public String getCarType() {
        return carType;
    }

    public void setCarId(String carId) {
        this.carId = carId;
    }

    public String getCarId() {
        return carId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserId() {
        return userId;
    }

    public void setRepairStat(String repairStat) {
        this.repairStat = repairStat;
    }
    public String getRepairStat() {
        return repairStat;
    }

    public void setStartDt(String startDt) {
        if (startDt != null && !"".equals(startDt)) {
            this.startDt = startDt.replaceAll("[^0-9]","");
        } else {
            this.startDt = "";
        }
    }

    public String getStartDt() {
        String rValue = startDt ;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        if (startDt != null && !"".equals(startDt)) {
            try {
                Date date = sdf.parse(startDt);
                rValue = sdf1.format(date);
            } catch (ParseException e) {

            }
        }
        return rValue;
    }

    public void setEndDt(String endDt) {
        if (endDt != null && !"".equals(endDt)) {
            this.endDt = endDt.replaceAll("[^0-9]","");
        } else {
            this.endDt = "" ;
        }
    }

    public String getEndDt() {
        String rValue = endDt ;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        if (endDt != null && !"".equals(endDt)) {
            try {
                Date date = sdf.parse(endDt);
                rValue = sdf1.format(date);
            } catch (ParseException e) {

            }
        }
        return rValue;
    }

    public void setChlgoDt(String chlgoDt) {
        this.chlgoDt = chlgoDt;
    }

    public String getChlgoDt() {
        return chlgoDt;
    }
}
