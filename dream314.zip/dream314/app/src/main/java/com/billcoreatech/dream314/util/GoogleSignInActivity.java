package com.billcoreatech.dream314.util;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.billcoreatech.dream314.R;
import com.billcoreatech.dream314.databinding.ActivityGoogleBinding;
import com.billcoreatech.dream314.ipgo.ChlgoActivity;
import com.billcoreatech.dream314.ipgo.IpgoActivity;
import com.billcoreatech.dream314.process.RepairActivity;
import com.billcoreatech.dream314.process.RepairDashboardActivity;
import com.billcoreatech.dream314.userManager.ManagerView;
import com.billcoreatech.dream314.userManager.UserBean;
import com.billcoreatech.dream314.userManager.UserManager;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


/**
 * Demonstrate Firebase Authentication using a Google ID Token.
 */
public class GoogleSignInActivity extends BaseActivity implements
        View.OnClickListener {

    private static final String TAG = "GoogleActivity";
    private static final int RC_SIGN_IN = 9001;

    // [START declare_auth]
    FirebaseAuth mAuth;
    // [END declare_auth]

    GoogleSignInClient mGoogleSignInClient;
    ActivityGoogleBinding mBinding;
    DatabaseReference userInfo;
    SharedPreferences sp ;
    String strMode = "" ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinding = ActivityGoogleBinding.inflate(getLayoutInflater());
        setContentView(mBinding.getRoot());
        //setProgressBar(mBinding.progressBar);
        sp = getSharedPreferences("appCode", MODE_PRIVATE);
        Intent intent = getIntent() ;
        strMode = intent.getStringExtra("mode") ;
        userInfo = FirebaseDatabase.getInstance().getReference(StringUtil.getAppCode(getApplicationContext()) + "users");
        // Button listeners
        mBinding.signInButton.setOnClickListener(this);
        mBinding.signOutButton.setOnClickListener(this);
        mBinding.disconnectButton.setOnClickListener(this);

        // [START config_signin]
        // Configure Google Sign In
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        // [END config_signin]

        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        // [START initialize_auth]
        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();
        // [END initialize_auth]
    }

    // [START on_start_check_user]
    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        updateUI(currentUser);
    }
    // [END on_start_check_user]

    // [START onactivityresult]
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Log.i(TAG, "requestCode=" + requestCode + " resultCode=" + resultCode) ;

        // Result returned from launching the Intent from GoogleSignInApi.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                // Google Sign In was successful, authenticate with Firebase
                GoogleSignInAccount account = task.getResult(ApiException.class);
                Log.i(TAG, "firebaseAuthWithGoogle:" + account.getId());
                firebaseAuthWithGoogle(account.getIdToken());
            } catch (ApiException e) {
                // Google Sign In failed, update UI appropriately
                Log.e(TAG, "Google sign in failed", e);
                // [START_EXCLUDE]
                updateUI(null);
                // [END_EXCLUDE]
            }
        } else if (requestCode == 999) {
            Log.i(TAG, "no Confirm User ............................... ") ;
            /**
             * 승인되지 않은 사용자는 사용할 수 없음
             */
            signOut();
        }
    }
    // [END onactivityresult]

    // [START auth_with_google]
    private void firebaseAuthWithGoogle(String idToken) {
        // [START_EXCLUDE silent]
        showProgressBar();
        // [END_EXCLUDE]
        AuthCredential credential = GoogleAuthProvider.getCredential(idToken, null);
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d(TAG, "signInWithCredential:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                            updateUI(user);
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w(TAG, "signInWithCredential:failure", task.getException());
                            Snackbar.make(mBinding.mainLayout, "Authentication Failed.", Snackbar.LENGTH_SHORT).show();
                            updateUI(null);
                        }

                        // [START_EXCLUDE]
                        hideProgressBar();
                        // [END_EXCLUDE]
                    }
                });
    }
    // [END auth_with_google]

    // [START signin]
    private void signIn() {
        Log.i(TAG, "signIn.........") ;
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }
    // [END signin]

    private void signOut() {
        // Firebase sign out
        mAuth.signOut();

        // Google sign out
        mGoogleSignInClient.signOut().addOnCompleteListener(this,
                new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        updateUI(null);
                    }
                });
    }

    private void revokeAccess() {
        // Firebase sign out
        mAuth.signOut();

        // Google revoke access
        mGoogleSignInClient.revokeAccess().addOnCompleteListener(this,
                new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        updateUI(null);
                    }
                });
    }

    private void updateUI(FirebaseUser user) {
        hideProgressBar();
        if (user != null) {
            Log.i(TAG, "login===" + user.getEmail());
            String[] id = user.getEmail().split("@");
            userInfo.orderByKey().equalTo(id[0]).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    int iCnt = 0 ;
                    for(DataSnapshot dataSnapshot : snapshot.getChildren()) {
                        iCnt++;
                        if ("Y".equals(dataSnapshot.getValue(UserBean.class).getUseYn())) {
                            if("memberJoin".equals(strMode)) {

                                Log.d(TAG, user.getDisplayName()) ;
                                Log.d(TAG, user.getEmail()) ;

                                Intent intent = new Intent(GoogleSignInActivity.this, UserManager.class);
                                intent.putExtra("userEmail", user.getEmail()) ;
                                intent.putExtra("userName", user.getDisplayName()) ;
                                startActivityForResult(intent, 100);

                            } else if ("managerLogin".equals(strMode)) {

                                Intent intent = new Intent(GoogleSignInActivity.this, ManagerView.class);
                                intent.putExtra("userEmail", user.getEmail()) ;
                                intent.putExtra("userName", user.getDisplayName()) ;
                                startActivityForResult(intent, 200);

                            } else if ("newRepair".equals(strMode)) {

                                Intent intent = new Intent(GoogleSignInActivity.this, IpgoActivity.class);
                                intent.putExtra("userEmail", user.getEmail()) ;
                                intent.putExtra("userName", user.getDisplayName()) ;
                                startActivityForResult(intent, 300);

                            } else if ("repairProcess".equals(strMode)) {

                                Intent intent = new Intent(GoogleSignInActivity.this, RepairActivity.class);
                                intent.putExtra("userEmail", user.getEmail()) ;
                                intent.putExtra("userName", user.getDisplayName()) ;
                                startActivityForResult(intent, 400);

                            } else if ("CompletedList".equals(strMode)) {

                                Intent intent = new Intent(GoogleSignInActivity.this, ChlgoActivity.class);
                                intent.putExtra("userEmail", user.getEmail()) ;
                                intent.putExtra("userName", user.getDisplayName()) ;
                                startActivityForResult(intent, 500);

                            } else if ("RepairDashboard".equals(strMode)) {
                                Intent intent = new Intent(GoogleSignInActivity.this, RepairDashboardActivity.class);
                                intent.putExtra("userEmail", user.getEmail()) ;
                                intent.putExtra("userName", user.getDisplayName()) ;
                                startActivityForResult(intent, 600);
                            }

                            finish();
                        } else {

                            Log.d(TAG, "displayName=" + user.getDisplayName()) ;
                            Log.d(TAG, "Email=" + user.getEmail()) ;

                            Intent intent = new Intent(GoogleSignInActivity.this, UserManager.class);
                            intent.putExtra("userEmail", user.getEmail()) ;
                            intent.putExtra("userName", user.getDisplayName()) ;
                            startActivityForResult(intent, 999);

                        }

                        Log.i(TAG, ">>>" + user.getEmail()) ;

                    }

                    if (iCnt == 0) {
                        Toast.makeText(getApplicationContext(), getString(R.string.msgLoginAgain), Toast.LENGTH_LONG).show();
                        Log.i(TAG, "not found >>>" + user.getEmail());
                        String[] id = user.getEmail().split("@");
                        UserBean userBean = new UserBean();
                        userBean.setAppCode(StringUtil.getAppCode(getApplicationContext()));
                        userBean.setUserEmail(user.getEmail());
                        userInfo.child(id[0]).setValue(userBean);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.i(TAG, "onCancelled found >>>" + user.getEmail()) ;
                }
            });

        } else {

            Log.i(TAG, "not login===" );

            mBinding.status.setText(R.string.msgGoogleLogin);
            mBinding.detail.setText(null);

            mBinding.signInButton.setVisibility(View.VISIBLE);
            mBinding.signOutAndDisconnect.setVisibility(View.GONE);
        }
    }

    @Override
    public void onClick(View v) {
        int i = v.getId();
        if (i == R.id.signInButton) {
            signIn();
        } else if (i == R.id.signOutButton) {
            signOut();
        } else if (i == R.id.disconnectButton) {
            revokeAccess();
        }
    }
}