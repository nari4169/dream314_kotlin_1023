package com.billcoreatech.dream314.ipgo;

import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.billcoreatech.dream314.R;
import com.billcoreatech.dream314.codeItem.CodeBean;
import com.billcoreatech.dream314.databinding.ActivityIpgoBinding;
import com.billcoreatech.dream314.databinding.RepairnewBinding;
import com.billcoreatech.dream314.util.StringUtil;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;

public class IpgoActivity extends AppCompatActivity {

    String TAG = "IpgoActivity" ;
    ActivityIpgoBinding binding ;
    RepairnewBinding repairBinding ;
    DatabaseReference mDatabase;
    DatabaseReference repairWork ;
    DatabaseReference codeItem;
    ArrayList<CodeBean> codeBeanArrayList ;
    ArrayList<CarRepairBean> carRepairBeanArrayList ;
    CarRepairAdapter adapter ;
    boolean isDisp = false ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityIpgoBinding.inflate(getLayoutInflater());
        View view = binding.getRoot() ;
        setContentView(view);

        carRepairBeanArrayList = new ArrayList<>();
        codeBeanArrayList = new ArrayList<>();

        mDatabase = FirebaseDatabase.getInstance().getReference(StringUtil.getAppCode(getApplicationContext()) + "carRepair");
        repairWork = FirebaseDatabase.getInstance().getReference(StringUtil.getAppCode(getApplicationContext()) + "repairWork");
        codeItem = FirebaseDatabase.getInstance().getReference(StringUtil.getAppCode(getApplicationContext()) + "codeItem");

        binding.btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        binding.btnAppend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                View repairView = getAlertView("");
                AlertDialog.Builder builder = new AlertDialog.Builder(IpgoActivity.this);
                builder.setTitle(getString(R.string.newrepair))
                        .setView(repairView)
                        .setPositiveButton(getString(R.string.save), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                CarRepairBean carRepairBean = new CarRepairBean();
                                carRepairBean.setCarType(repairBinding.txtCarType.getText().toString());
                                carRepairBean.setCarId(repairBinding.txtCarId.getText().toString());
                                carRepairBean.setIpgoDt(repairBinding.txtIpgoDt.getText().toString());
                                carRepairBean.setChlgoDt(repairBinding.txtChlgoDt.getText().toString());
                                carRepairBean.setRepairYn1("");
                                carRepairBean.setRepairYn2("");
                                carRepairBean.setRepairYn3("");
                                carRepairBean.setRepairYn4("");
                                carRepairBean.setRepairYn5("");
                                carRepairBean.setRepairYn6("");
                                carRepairBean.setRepairYn7("");
                                carRepairBean.setRepairYn8("");
                                carRepairBean.setRepairYn9("");
                                if (repairBinding.checkBox.isChecked()) {
                                    carRepairBean.setRepairYn1("Y");
                                }
                                if (repairBinding.checkBox2.isChecked()) {
                                    carRepairBean.setRepairYn2("Y");
                                }
                                if (repairBinding.checkBox3.isChecked()) {
                                    carRepairBean.setRepairYn3("Y");
                                }
                                if (repairBinding.checkBox4.isChecked()) {
                                    carRepairBean.setRepairYn4("Y");
                                }
                                if (repairBinding.checkBox5.isChecked()) {
                                    carRepairBean.setRepairYn5("Y");
                                }
                                carRepairBean.setRepairCnt(getRepairCnt(carRepairBean));
                                carRepairBean.setRepairCompleteYn("N");
                                if ("".equals(repairBinding.txtCarId.getText().toString())) {
                                   Toast.makeText(getApplicationContext(), getString(R.string.msgEnterCarId), Toast.LENGTH_LONG).show();
                                } else {
                                    mDatabase.child(repairBinding.txtCarId.getText().toString()).setValue(carRepairBean);
                                    Toast.makeText(getApplicationContext(), getString(R.string.msgSaveCompleted), Toast.LENGTH_LONG).show();
                                    getDisplayData();
                                }
                            }
                        })
                        .setNegativeButton(getString(R.string.close), null) ;
                AlertDialog dialog = builder.create();
                dialog.show();
                dialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(Color.BLUE);
                dialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(Color.GRAY);
            }
        });

        binding.repairList.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                Log.i(TAG, "scrollState=" + scrollState);
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                Log.i(TAG, "firstVisibleItem=" + firstVisibleItem);
                Log.i(TAG, "visibleItemCount=" + visibleItemCount);
                Log.i(TAG, "totalItemCount=" + totalItemCount);

            }
        });

        binding.repairList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                View repairView = getAlertView(String.valueOf(position));
                repairBinding.txtCarType.setText(carRepairBeanArrayList.get(position).getCarType());
                repairBinding.txtCarId.setText(carRepairBeanArrayList.get(position).getCarId());
                repairBinding.txtIpgoDt.setText(carRepairBeanArrayList.get(position).getIpgoDt());
                repairBinding.txtChlgoDt.setText(carRepairBeanArrayList.get(position).getChlgoDt());
                repairBinding.checkBox.setChecked(false);
                repairBinding.checkBox2.setChecked(false);
                repairBinding.checkBox3.setChecked(false);
                repairBinding.checkBox4.setChecked(false);
                repairBinding.checkBox5.setChecked(false);
                if("Y".equals(carRepairBeanArrayList.get(position).getRepairYn1())) {
                    repairBinding.checkBox.setChecked(true);
                }
                if("Y".equals(carRepairBeanArrayList.get(position).getRepairYn2())) {
                    repairBinding.checkBox2.setChecked(true);
                }
                if("Y".equals(carRepairBeanArrayList.get(position).getRepairYn3())) {
                    repairBinding.checkBox3.setChecked(true);
                }
                if("Y".equals(carRepairBeanArrayList.get(position).getRepairYn4())) {
                    repairBinding.checkBox4.setChecked(true);
                }
                if("Y".equals(carRepairBeanArrayList.get(position).getRepairYn5())) {
                    repairBinding.checkBox5.setChecked(true);
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(IpgoActivity.this);
                builder.setTitle(getString(R.string.modifyrepair))
                        .setView(repairView)
                        .setPositiveButton(getString(R.string.save), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                CarRepairBean carRepairBean = new CarRepairBean();
                                carRepairBean.setCarType(repairBinding.txtCarType.getText().toString());
                                carRepairBean.setCarId(repairBinding.txtCarId.getText().toString());
                                carRepairBean.setIpgoDt(repairBinding.txtIpgoDt.getText().toString());
                                carRepairBean.setChlgoDt(repairBinding.txtChlgoDt.getText().toString());
                                carRepairBean.setRepairYn1("");
                                carRepairBean.setRepairYn2("");
                                carRepairBean.setRepairYn3("");
                                carRepairBean.setRepairYn4("");
                                carRepairBean.setRepairYn5("");
                                carRepairBean.setRepairYn6("");
                                carRepairBean.setRepairYn7("");
                                carRepairBean.setRepairYn8("");
                                carRepairBean.setRepairYn9("");
                                if (repairBinding.checkBox.isChecked()) {
                                    carRepairBean.setRepairYn1("Y");
                                }
                                if (repairBinding.checkBox2.isChecked()) {
                                    carRepairBean.setRepairYn2("Y");
                                }
                                if (repairBinding.checkBox3.isChecked()) {
                                    carRepairBean.setRepairYn3("Y");
                                }
                                if (repairBinding.checkBox4.isChecked()) {
                                    carRepairBean.setRepairYn4("Y");
                                }
                                if (repairBinding.checkBox5.isChecked()) {
                                    carRepairBean.setRepairYn5("Y");
                                }
                                if ("".equals(repairBinding.txtCarId.getText().toString())) {
                                    Toast.makeText(getApplicationContext(), getString(R.string.msgEnterCarId), Toast.LENGTH_LONG).show();
                                } else {
                                    // 차량번호는 PK 인데 변경을 하겠다면 기존꺼 삭제 하고 다시 등록 하기.
                                    if (!carRepairBeanArrayList.get(position).getCarId().equals(carRepairBean.getCarId())) {
                                        mDatabase.child(carRepairBeanArrayList.get(position).getCarId()).removeValue() ;
                                    }
                                    carRepairBean.setRepairCnt(getRepairCnt(carRepairBean));
                                    carRepairBean.setRepairCompleteYn("N");
                                    mDatabase.child(repairBinding.txtCarId.getText().toString()).setValue(carRepairBean) ;
                                    Toast.makeText(getApplicationContext(), getString(R.string.msgSaveCompleted), Toast.LENGTH_LONG).show();
                                    getDisplayData();
                                }
                            }
                        })
                        .setNeutralButton(getString(R.string.delete), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                AlertDialog.Builder builder = new AlertDialog.Builder(IpgoActivity.this);
                                builder.setTitle(getString(R.string.delete))
                                        .setMessage(getString(R.string.msgDelete))
                                        .setPositiveButton(getString(R.string.OK), new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {

                                                mDatabase.child(carRepairBeanArrayList.get(position).getCarId()).removeValue() ;
                                                for(CodeBean codeBean : codeBeanArrayList) {
                                                    String repairWorkKey = codeBean.getPrvCd() + carRepairBeanArrayList.get(position).getCarId();
                                                    repairWork.child(repairWorkKey).removeValue();
                                                }
                                                Toast.makeText(getApplicationContext(), getString(R.string.msgDeleteCompleted), Toast.LENGTH_LONG).show();
                                                getDisplayData();
                                            }
                                        })
                                        .setNegativeButton(getString(R.string.cancel), null);
                                AlertDialog dialog1 = builder.create();
                                dialog1.show();
                                dialog1.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(Color.BLUE);
                                dialog1.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(Color.GRAY);
                            }
                        })
                        .setNegativeButton(getString(R.string.close), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                getDisplayData();
                            }
                        }) ;
                AlertDialog dialog = builder.create();
                dialog.show();
                dialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(Color.BLUE);
                dialog.getButton(DialogInterface.BUTTON_NEUTRAL).setTextColor(Color.RED);
                dialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(Color.GRAY);
            }
        });

        binding.btnFind1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText edCarId = new EditText(IpgoActivity.this);
                edCarId.setSingleLine(true);
                AlertDialog.Builder builder = new AlertDialog.Builder(IpgoActivity.this);
                builder.setTitle(getString(R.string.find))
                        .setMessage(getString(R.string.msgFindCarId))
                        .setView(edCarId)
                        .setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                onFindCarId(edCarId.getText().toString()) ;
                            }
                        })
                        .setNegativeButton(getString(R.string.close), null);
                AlertDialog dialog = builder.create();
                dialog.show();
                dialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(Color.BLUE);
                dialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(Color.GRAY);
            }
        });

        getDisplayData() ;
    }

    private void onFindCarId(String pCarID) {

        binding.baseProgressBar.setVisibility(View.VISIBLE);
        mDatabase.orderByChild("carId").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                carRepairBeanArrayList.clear();
                for(DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    CarRepairBean carRepairBean = new CarRepairBean();
                    try {
                        carRepairBean = dataSnapshot.getValue(CarRepairBean.class);
                        Log.i(TAG, "carId=" + carRepairBean.getCarId());
                        if (carRepairBean.getCarId().contains(pCarID)) {
                            if ("N".equals(carRepairBean.getRepairCompleteYn())) {
                                carRepairBeanArrayList.add(carRepairBean);
                            }
                        }
                    } catch (Exception e) {

                    }
                }
                adapter = new CarRepairAdapter(getApplicationContext(), carRepairBeanArrayList, codeBeanArrayList) ;
                adapter.updateReceiptsList(carRepairBeanArrayList);
                binding.repairList.setAdapter(adapter);
                binding.baseProgressBar.setVisibility(View.GONE);
                Toast.makeText(getApplicationContext(), getString(R.string.msgFindCompleted), Toast.LENGTH_LONG).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        }) ;

    }

    /**
     * 등록할 때 수리 대상 작업 건수를 저장하기 위해서
     * @param carRepairBean
     * @return
     */
    private int getRepairCnt(CarRepairBean carRepairBean) {
        int iCnt = 0 ;
        if ("Y".equals(carRepairBean.getRepairYn1())) {
            iCnt++;
        }
        if ("Y".equals(carRepairBean.getRepairYn2())) {
            iCnt++;
        }
        if ("Y".equals(carRepairBean.getRepairYn3())) {
            iCnt++;
        }
        if ("Y".equals(carRepairBean.getRepairYn4())) {
            iCnt++;
        }
        if ("Y".equals(carRepairBean.getRepairYn5())) {
            iCnt++;
        }
        if ("Y".equals(carRepairBean.getRepairYn6())) {
            iCnt++;
        }
        if ("Y".equals(carRepairBean.getRepairYn7())) {
            iCnt++;
        }
        if ("Y".equals(carRepairBean.getRepairYn8())) {
            iCnt++;
        }
        if ("Y".equals(carRepairBean.getRepairYn9())) {
            iCnt++;
        }
        return iCnt ;
    }

    /**
     * 입력 수정 alertDialog 화면 설정
     *
     * @return
     */
    private View getAlertView(String sPosition) {
        repairBinding = RepairnewBinding.inflate(getLayoutInflater()) ;
        View repairView = repairBinding.getRoot() ;
        for(int i = 0 ; i < codeBeanArrayList.size() ; i++) {
            switch (i) {
                case 0: repairBinding.checkBox.setText(codeBeanArrayList.get(i).getPrvNm()); break ;
                case 1: repairBinding.checkBox2.setText(codeBeanArrayList.get(i).getPrvNm()); break ;
                case 2: repairBinding.checkBox3.setText(codeBeanArrayList.get(i).getPrvNm()); break ;
                case 3: repairBinding.checkBox4.setText(codeBeanArrayList.get(i).getPrvNm()); break ;
                case 4: repairBinding.checkBox5.setText(codeBeanArrayList.get(i).getPrvNm()); break ;
            }
        }
        repairBinding.txtIpgoDt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                if (!"".equals(repairBinding.txtIpgoDt.getText().toString())) {
                    String cDate = repairBinding.txtIpgoDt.getText().toString().replaceAll("[^0-9]","");
                    cal.set(Integer.parseInt(cDate.substring(0, 4)),
                            Integer.parseInt(cDate.substring(4, 6)) - 1,
                            Integer.parseInt(cDate.substring(6, 8)));
                }
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(IpgoActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        repairBinding.txtIpgoDt.setText(year + "-" + lpad(month + 1) + "-" + lpad(dayOfMonth)) ;
                    }
                }, year, month, day) ;
                datePickerDialog.show();
            }
        });
        repairBinding.txtChlgoDt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                if (!"".equals(repairBinding.txtChlgoDt.getText().toString())) {
                    String cDate = repairBinding.txtChlgoDt.getText().toString().replaceAll("[^0-9]","");
                    cal.set(Integer.parseInt(cDate.substring(0, 4)),
                            Integer.parseInt(cDate.substring(4, 6)) - 1,
                            Integer.parseInt(cDate.substring(6, 8)));
                }
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(IpgoActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        repairBinding.txtChlgoDt.setText(year + "-" + lpad(month + 1) + "-" + lpad(dayOfMonth)) ;
                    }
                }, year, month, day) ;
                datePickerDialog.show();
            }
        });

        repairBinding.checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!"".equals(sPosition)) {
                    int pos = Integer.parseInt(sPosition);
                    Log.i(TAG, " pos=" + pos + ":" + carRepairBeanArrayList.get(pos).getRepairYn1()) ;
                    if ("C".equals(carRepairBeanArrayList.get(pos).getRepairYn1())) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(IpgoActivity.this);
                        builder.setTitle(getString(R.string.confirm))
                                .setMessage(getString(R.string.msgUncheckCompleted))
                                .setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        carRepairBeanArrayList.get(pos).setRepairYn1("Y");
                                        repairBinding.checkBox.setChecked(true);
                                    }
                                })
                                .setNegativeButton(getString(R.string.close), new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        carRepairBeanArrayList.get(pos).setRepairYn1("C");
                                        repairBinding.checkBox.setChecked(false);
                                    }
                                });
                        AlertDialog dialog = builder.create() ;
                        dialog.show();
                    }
                }
            }
        });

        repairBinding.checkBox2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!"".equals(sPosition)) {
                    int pos = Integer.parseInt(sPosition);
                    Log.i(TAG, " pos=" + pos + ":" + carRepairBeanArrayList.get(pos).getRepairYn2()) ;
                    if ("C".equals(carRepairBeanArrayList.get(pos).getRepairYn2())) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(IpgoActivity.this);
                        builder.setTitle(getString(R.string.confirm))
                                .setMessage(getString(R.string.msgUncheckCompleted))
                                .setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        carRepairBeanArrayList.get(pos).setRepairYn2("Y");
                                        repairBinding.checkBox2.setChecked(true);
                                    }
                                })
                                .setNegativeButton(getString(R.string.close), new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        carRepairBeanArrayList.get(pos).setRepairYn2("C");
                                        repairBinding.checkBox2.setChecked(false);
                                    }
                                });
                        AlertDialog dialog = builder.create() ;
                        dialog.show();
                    }
                }
            }
        });

        repairBinding.checkBox3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!"".equals(sPosition)) {
                    int pos = Integer.parseInt(sPosition);
                    Log.i(TAG, " pos=" + pos + ":" + carRepairBeanArrayList.get(pos).getRepairYn3()) ;
                    if ("C".equals(carRepairBeanArrayList.get(pos).getRepairYn3())) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(IpgoActivity.this);
                        builder.setTitle(getString(R.string.confirm))
                                .setMessage(getString(R.string.msgUncheckCompleted))
                                .setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        carRepairBeanArrayList.get(pos).setRepairYn3("Y");
                                        repairBinding.checkBox3.setChecked(true);
                                    }
                                })
                                .setNegativeButton(getString(R.string.close), new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        carRepairBeanArrayList.get(pos).setRepairYn3("C");
                                        repairBinding.checkBox3.setChecked(false);
                                    }
                                });
                        AlertDialog dialog = builder.create() ;
                        dialog.show();
                    }
                }
            }
        });

        repairBinding.checkBox4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!"".equals(sPosition)) {
                    int pos = Integer.parseInt(sPosition);
                    Log.i(TAG, " pos=" + pos + ":" + carRepairBeanArrayList.get(pos).getRepairYn4()) ;
                    if ("C".equals(carRepairBeanArrayList.get(pos).getRepairYn4())) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(IpgoActivity.this);
                        builder.setTitle(getString(R.string.confirm))
                                .setMessage(getString(R.string.msgUncheckCompleted))
                                .setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        carRepairBeanArrayList.get(pos).setRepairYn4("Y");
                                        repairBinding.checkBox4.setChecked(true);
                                    }
                                })
                                .setNegativeButton(getString(R.string.close), new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        carRepairBeanArrayList.get(pos).setRepairYn4("C");
                                        repairBinding.checkBox4.setChecked(false);
                                    }
                                });
                        AlertDialog dialog = builder.create() ;
                        dialog.show();
                    }
                }
            }
        });

        repairBinding.checkBox5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!"".equals(sPosition)) {
                    int pos = Integer.parseInt(sPosition);
                    Log.i(TAG, " pos=" + pos + ":" + carRepairBeanArrayList.get(pos).getRepairYn5()) ;
                    if ("C".equals(carRepairBeanArrayList.get(pos).getRepairYn5())) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(IpgoActivity.this);
                        builder.setTitle(getString(R.string.confirm))
                                .setMessage(getString(R.string.msgUncheckCompleted))
                                .setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        carRepairBeanArrayList.get(pos).setRepairYn5("Y");
                                        repairBinding.checkBox5.setChecked(true);
                                    }
                                })
                                .setNegativeButton(getString(R.string.close), new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        carRepairBeanArrayList.get(pos).setRepairYn5("C");
                                        repairBinding.checkBox5.setChecked(false);
                                    }
                                });
                        AlertDialog dialog = builder.create() ;
                        dialog.show();
                    }
                }
            }
        });


        return repairView ;
    }

    /**
     * 2자리 숫자 만들어서 문자로 회신
     * @param i
     * @return
     */
    private String lpad(int i) {
        return i < 10 ? "0" + i : String.valueOf(i) ;
    }

    /**
     * 데이터 조회
     */
    private void getDisplayData() {

        binding.baseProgressBar.setVisibility(View.VISIBLE);
        codeItem.orderByChild("useYn").equalTo("Y").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int i = 0 ;
                codeBeanArrayList.clear();
                for(DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    codeBeanArrayList.add(dataSnapshot.getValue(CodeBean.class));
                }
                binding.baseProgressBar.setVisibility(View.GONE);

                binding.baseProgressBar.setVisibility(View.VISIBLE);
                mDatabase.orderByChild("repairCompleteYn").equalTo("N").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        carRepairBeanArrayList.clear();
                        for(DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            CarRepairBean carRepairBean = dataSnapshot.getValue(CarRepairBean.class);
                            if (carRepairBean.getRepairCnt() == getRepairCompletedCnt(carRepairBean)) {
                                mDatabase.child(carRepairBean.getCarId()).child("repairCompleteYn").setValue("C");
                                carRepairBean.setRepairCompleteYn("C");
                            }
                            carRepairBeanArrayList.add(carRepairBean);
                            Log.i(TAG, "carId=" + dataSnapshot.getValue(CarRepairBean.class).getCarId());
                        }
                        adapter = new CarRepairAdapter(getApplicationContext(), carRepairBeanArrayList, codeBeanArrayList) ;
                        adapter.updateReceiptsList(carRepairBeanArrayList);
                        binding.repairList.setAdapter(adapter);
                        binding.baseProgressBar.setVisibility(View.GONE);
                        isDisp = true ;
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                }) ;
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        }) ;


    }

    /**
     * 수리가 완료된 작업의 수를 구함
     * @param carRepairBean
     * @return
     */
    private int getRepairCompletedCnt(CarRepairBean carRepairBean) {
        int iCnt = 0 ;
        if ("C".equals(carRepairBean.getRepairYn1())) {
            iCnt++;
        }
        if ("C".equals(carRepairBean.getRepairYn2())) {
            iCnt++;
        }
        if ("C".equals(carRepairBean.getRepairYn3())) {
            iCnt++;
        }
        if ("C".equals(carRepairBean.getRepairYn4())) {
            iCnt++;
        }
        if ("C".equals(carRepairBean.getRepairYn5())) {
            iCnt++;
        }
        if ("C".equals(carRepairBean.getRepairYn6())) {
            iCnt++;
        }
        if ("C".equals(carRepairBean.getRepairYn7())) {
            iCnt++;
        }
        if ("C".equals(carRepairBean.getRepairYn8())) {
            iCnt++;
        }
        if ("C".equals(carRepairBean.getRepairYn9())) {
            iCnt++;
        }
        return iCnt ;
    }

}