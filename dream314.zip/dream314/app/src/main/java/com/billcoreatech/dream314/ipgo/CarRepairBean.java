package com.billcoreatech.dream314.ipgo;

public class CarRepairBean {

    String appCode ;
    String carType ;
    String carId ;
    String ipgoDt ;
    String chlgoDt ;
    String repairYn1 ;
    String repairYn2 ;
    String repairYn3 ;
    String repairYn4 ;
    String repairYn5 ;
    String repairYn6 ;
    String repairYn7 ;
    String repairYn8 ;
    String repairYn9 ;
    String repairCompleteYn ;
    int repairCnt ;

    public void setAppCode(String appCode) {
        this.appCode = appCode;
    }

    public String getAppCode() {
        return appCode;
    }

    public void setCarType(String carType) {
        this.carType = carType;
    }

    public String getCarType() {
        return carType;
    }

    public void setCarId(String carId) {
        this.carId = carId;
    }

    public String getCarId() {
        return carId;
    }

    public void setIpgoDt(String ipgoDt) {
        this.ipgoDt = ipgoDt.replaceAll("[^0-9]","");
    }

    public String getIpgoDt() {
        if (ipgoDt.length() == 8) {
            return  ipgoDt.substring(0, 4) + "-" + ipgoDt.substring(4, 6) + "-" + ipgoDt.substring(6, 8) ;
        }
        return ipgoDt;
    }

    public void setChlgoDt(String chlgoDt) {
        this.chlgoDt = chlgoDt.replaceAll("[^0-9]","");
    }

    public String getChlgoDt() {
        if (chlgoDt.length() == 8) {
            return  chlgoDt.substring(0, 4) + "-" + chlgoDt.substring(4, 6) + "-" + chlgoDt.substring(6, 8) ;
        }
        return chlgoDt;
    }

    public void setRepairYn1(String repairYn1) {
        this.repairYn1 = repairYn1;
    }

    public String getRepairYn1() {
        return repairYn1;
    }

    public void setRepairYn2(String repairYn2) {
        this.repairYn2 = repairYn2;
    }

    public String getRepairYn2() {
        return repairYn2;
    }

    public void setRepairYn3(String repairYn3) {
        this.repairYn3 = repairYn3;
    }

    public String getRepairYn3() {
        return repairYn3;
    }

    public void setRepairYn4(String repairYn4) {
        this.repairYn4 = repairYn4;
    }

    public String getRepairYn4() {
        return repairYn4;
    }

    public void setRepairYn5(String repairYn5) {
        this.repairYn5 = repairYn5;
    }

    public String getRepairYn5() {
        return repairYn5;
    }

    public void setRepairYn6(String repairYn6) {
        this.repairYn6 = repairYn6;
    }

    public String getRepairYn6() {
        return repairYn6;
    }

    public void setRepairYn7(String repairYn7) {
        this.repairYn7 = repairYn7;
    }

    public String getRepairYn7() {
        return repairYn7;
    }

    public void setRepairYn8(String repairYn8) {
        this.repairYn8 = repairYn8;
    }

    public String getRepairYn8() {
        return repairYn8;
    }

    public void setRepairYn9(String repairYn9) {
        this.repairYn9 = repairYn9;
    }

    public String getRepairYn9() {
        return repairYn9;
    }

    public void setRepairCompleteYn(String repairCompleteYn) {
        this.repairCompleteYn = repairCompleteYn;
    }

    public String getRepairCompleteYn() {
        return repairCompleteYn;
    }

    public void setRepairCnt(int repairCnt) {
        this.repairCnt = repairCnt;
    }

    public int getRepairCnt() {
        return repairCnt;
    }
}
