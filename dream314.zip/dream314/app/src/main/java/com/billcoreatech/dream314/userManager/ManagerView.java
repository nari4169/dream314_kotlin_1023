package com.billcoreatech.dream314.userManager;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.billcoreatech.dream314.R;
import com.billcoreatech.dream314.codeItem.CodeBean;
import com.billcoreatech.dream314.codeItem.CodeItemAdapter;
import com.billcoreatech.dream314.databinding.ActivityManagerBinding;
import com.billcoreatech.dream314.databinding.CodeappendBinding;
import com.billcoreatech.dream314.util.StringUtil;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ManagerView extends AppCompatActivity {

    String TAG = "ManagerView" ;
    ActivityManagerBinding binding ;
    CodeappendBinding codeBinding ;
    FirebaseAuth mAuth;
    GoogleSignInClient mGoogleSignInClient;
    DatabaseReference mDatabase;
    DatabaseReference codeItem ;
    String userEmail ;
    String userName ;
    boolean isMaster = false ;
    ArrayList<CodeBean> codeBeanArrayList ;
    CodeItemAdapter adapter ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityManagerBinding.inflate(getLayoutInflater()) ;
        View view = binding.getRoot() ;
        setContentView(view);

        mDatabase = FirebaseDatabase.getInstance().getReference(StringUtil.getAppCode(getApplicationContext()) + "users");
        codeItem = FirebaseDatabase.getInstance().getReference(StringUtil.getAppCode(getApplicationContext()) + "codeItem");

        codeBeanArrayList = new ArrayList<>();

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
        mAuth = FirebaseAuth.getInstance();

        Intent intent = getIntent() ;
        userEmail = intent.getStringExtra("userEmail") ;
        userName = intent.getStringExtra("userName") ;

        binding.txtEmail.setText(userEmail) ;
        binding.inpUserName.setText(userName);

        binding.btnSignOut3.setVisibility(View.GONE);

        binding.btnSave3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!isMaster) {

                    Toast.makeText(getApplicationContext(), getString(R.string.msgMasterIsOne), Toast.LENGTH_LONG).show();

                } else {

                    UserBean user = new UserBean();
                    String[] id = userEmail.split("@"); // 메일주소 앞에만 사용 @을 사용할 수 없음
                    user.setUserEmail(userEmail);
                    user.setUserName(userName);
                    user.setUserPassword("");
                    user.setUserDept("Master");
                    user.setDeptCode("99");
                    user.setMasterTy("Y");
                    mDatabase.child(id[0]).setValue(user);

                    Toast.makeText(getApplicationContext(), getString(R.string.msgSaveCompleted), Toast.LENGTH_LONG).show();
                }
                onDisplayData() ;
            }
        });

        binding.btnCancel3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        binding.btnFind3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String[] id = userEmail.split("@") ; // 메일주소 앞에만 사용 @을 사용할 수 없음
                mDatabase.orderByChild("masterTy").equalTo("Y").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for(DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            Toast.makeText(getApplicationContext(), "[" + dataSnapshot.getValue(UserBean.class).getUserEmail() + "]"
                                    + getString(R.string.msgIsManager), Toast.LENGTH_LONG).show();
                            break;
                        }
                        Log.i(TAG, "find end ...") ;
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(getApplicationContext(), getString(R.string.msgNotManger), Toast.LENGTH_LONG).show();
                    }
                });
            }
        });

        binding.btnSignOut3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signOut() ;
            }
        });

        onDisplayData() ;


        binding.btnCodeAppend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                codeBinding = CodeappendBinding.inflate(getLayoutInflater());
                View codeView = codeBinding.getRoot() ;
                AlertDialog.Builder codeDialogBuilder = new AlertDialog.Builder(ManagerView.this) ;
                codeDialogBuilder.setTitle(getString(R.string.titleDeptCode))
                        .setView(codeView)
                        .setPositiveButton(getString(R.string.save), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                CodeBean codeBean = new CodeBean();
                                codeBean.setGrpCd("DEPT");
                                codeBean.setPrvCd(codeBinding.inpPrvCd.getText().toString());
                                codeBean.setPrvNm(codeBinding.inpPrvNm.getText().toString());
                                codeBean.setUseYn("Y");
                                codeItem.child("DEPT"+codeBinding.inpPrvCd.getText().toString()).setValue(codeBean);
                                Toast.makeText(getApplicationContext(), getString(R.string.msgSaveCompleted), Toast.LENGTH_LONG).show();
                                //onDispCodeItem() ;
                            }
                        })
                        .setNegativeButton(getString(R.string.cancel), null);
                AlertDialog codeDialog = codeDialogBuilder.create();
                codeDialog.show();
                codeDialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(Color.BLUE);
                codeDialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(Color.GRAY);
            }
        });

        binding.codeList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Log.i(TAG, "master=" + isMaster) ;

                if (!isMaster) {

                } else {

                    codeBinding = CodeappendBinding.inflate(getLayoutInflater());
                    View codeView = codeBinding.getRoot();
                    codeBinding.inpPrvCd.setText(codeBeanArrayList.get(position).getPrvCd());
                    codeBinding.inpPrvNm.setText(codeBeanArrayList.get(position).getPrvNm());
                    AlertDialog.Builder codeDialogBuilder = new AlertDialog.Builder(ManagerView.this);
                    codeDialogBuilder.setTitle(getString(R.string.titleDeptCode))
                            .setView(codeView)
                            .setPositiveButton(getString(R.string.save), new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    CodeBean codeBean = new CodeBean();
                                    codeBean.setGrpCd("DEPT");
                                    codeBean.setPrvCd(codeBinding.inpPrvCd.getText().toString());
                                    codeBean.setPrvNm(codeBinding.inpPrvNm.getText().toString());
                                    codeBean.setUseYn("Y");
                                    codeItem.child("DEPT"+codeBinding.inpPrvCd.getText().toString()).setValue(codeBean);
                                    Toast.makeText(getApplicationContext(), getString(R.string.msgSaveCompleted), Toast.LENGTH_LONG).show();
                                    //onDispCodeItem();
                                }
                            })
                            .setNeutralButton(getString(R.string.delete), new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    AlertDialog.Builder builder = new AlertDialog.Builder(ManagerView.this);
                                    builder.setTitle(getString(R.string.delete))
                                            .setMessage(getString(R.string.msgDelete))
                                            .setPositiveButton(getString(R.string.OK), new DialogInterface.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dialog, int which) {
                                                    codeItem.child("DEPT"+codeBinding.inpPrvCd.getText().toString()).removeValue();
                                                    Toast.makeText(getApplicationContext(), getString(R.string.msgDeleteCompleted), Toast.LENGTH_LONG).show();
                                                    //onDispCodeItem();
                                                }
                                            })
                                            .setNegativeButton(getString(R.string.cancel), null);
                                    AlertDialog dialog1 = builder.create();
                                    dialog1.show();
                                    dialog1.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(Color.BLUE);
                                    dialog1.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(Color.GRAY);
                                }
                            })
                            .setNegativeButton(getString(R.string.cancel), null);
                    AlertDialog codeDialog = codeDialogBuilder.create();
                    codeDialog.show();
                    codeDialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(Color.BLUE);
                    codeDialog.getButton(DialogInterface.BUTTON_NEUTRAL).setTextColor(Color.RED);
                    codeDialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(Color.GRAY);
                }
            }
        });
    }

    public void onDisplayData() {

        binding.baseProgressBar.setVisibility(View.VISIBLE);
        mDatabase.orderByChild("masterTy").equalTo("Y").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    if (userEmail.equals(dataSnapshot.getValue(UserBean.class).getUserEmail())) {
                        binding.txtEmail.setBackgroundColor(Color.YELLOW);
                        binding.inpUserName.setBackgroundColor(Color.YELLOW);
                        Toast.makeText(getApplicationContext(), getString(R.string.findManager), Toast.LENGTH_LONG).show();
                        isMaster = true ; // 관리자 로그인 시에는 저장할 수 있게...
                        break ;
                    };
                    Log.i(TAG, "onDisplayData=" + dataSnapshot.getValue(UserBean.class).getUserEmail());
                }
                Log.i(TAG, "find end ...") ;
                if (!isMaster) {
                    binding.btnSave3.setEnabled(false);
                    binding.btnCodeAppend.setEnabled(false);
                }
                binding.baseProgressBar.setVisibility(View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        onDispCodeItem() ;
    }

    public void onDispCodeItem() {

        binding.baseProgressBar.setVisibility(View.VISIBLE);
        codeItem.orderByChild("useYn").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                codeBeanArrayList.clear();
                for(DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    codeBeanArrayList.add(dataSnapshot.getValue(CodeBean.class));
                }
                adapter = new CodeItemAdapter(getApplicationContext(), codeBeanArrayList);
                adapter.updateReceiptsList(codeBeanArrayList);
                binding.codeList.setAdapter(adapter);
                binding.baseProgressBar.setVisibility(View.GONE);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        }) ;

    }

    private void signOut() {
        // Firebase sign out
        mAuth.signOut();

        // Google sign out
        mGoogleSignInClient.signOut().addOnCompleteListener(this,
                new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        finish();
                    }
                });
    }
}