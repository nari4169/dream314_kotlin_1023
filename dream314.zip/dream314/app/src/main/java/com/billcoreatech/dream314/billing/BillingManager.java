package com.billcoreatech.dream314.billing;

import android.app.Activity;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.ConsumeParams;
import com.android.billingclient.api.ConsumeResponseListener;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.SkuDetails;
import com.android.billingclient.api.SkuDetailsParams;
import com.android.billingclient.api.SkuDetailsResponseListener;
import com.billcoreatech.dream314.R;
import com.billcoreatech.dream314.util.StringUtil;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.gson.JsonObject;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class BillingManager<mConsumResListnere> implements PurchasesUpdatedListener {
    String TAG = "BillingManager" ;
    BillingClient mBillingClient ;
    Activity mActivity ;
    public List<SkuDetails> mSkuDetails ;
    public enum connectStatusTypes { waiting, connected, fail, disconnected }
    public connectStatusTypes connectStatus = connectStatusTypes.waiting ;
    private ConsumeResponseListener mConsumResListnere ;
    DatabaseReference userinfoDB;
    BillinguserBean billinguserBean;
    String billCode = "210420_onetime_pay" ;

    public BillingManager (Activity _activity) {
        mActivity = _activity ;

        mBillingClient = BillingClient.newBuilder(mActivity)
                .setListener(this)
                .enablePendingPurchases()
                .build() ;
        mBillingClient.startConnection(new BillingClientStateListener() {
            @Override
            public void onBillingSetupFinished(@NonNull BillingResult billingResult) {
                Log.i(TAG, "respCode=" + billingResult.getResponseCode() ) ;
                if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    connectStatus = connectStatusTypes.connected ;
                    Log.i(TAG, "connected...") ;

                    Log.i(TAG, "resp=" + mBillingClient.queryPurchases(billCode).getBillingResult()
                             + "=" + mBillingClient.queryPurchases(billCode).getResponseCode());

                    getSkuDetailList() ;

                } else {
                    connectStatus = connectStatusTypes.fail ;
                    Log.i(TAG, "connected... fail ") ;
                }
            }

            @Override
            public void onBillingServiceDisconnected() {
                connectStatus = connectStatusTypes.disconnected ;
                Log.i(TAG, "disconnected ") ;
            }
        });

        mConsumResListnere = new ConsumeResponseListener() {
            @Override
            public void onConsumeResponse(@NonNull BillingResult billingResult, @NonNull String purchaseToken) {
                if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    Log.i(TAG, "사용끝 + " + purchaseToken) ;
                    return ;
                } else {
                    Log.i(TAG, "소모에 실패 " + billingResult.getResponseCode() + " 대상 상품 " + purchaseToken) ;
                    return ;
                }
            }
        };
    }

    public int purchase(SkuDetails skuDetails) {
        BillingFlowParams flowParams = BillingFlowParams.newBuilder()
                .setSkuDetails(skuDetails)
                .build();
        return mBillingClient.launchBillingFlow(mActivity, flowParams).getResponseCode();
    }


    public void getSkuDetailList() {
        List<String> skuIdList = new ArrayList<>() ;
        skuIdList.add(billCode);

        SkuDetailsParams.Builder params = SkuDetailsParams.newBuilder();
        params.setSkusList(skuIdList).setType(BillingClient.SkuType.INAPP);
        mBillingClient.querySkuDetailsAsync(params.build(), new SkuDetailsResponseListener() {
            @Override
            public void onSkuDetailsResponse(@NonNull BillingResult billingResult, @Nullable List<SkuDetails> skuDetailsList) {
                if (billingResult.getResponseCode() != BillingClient.BillingResponseCode.OK) {
                    Log.i(TAG, "detail respCode=" + billingResult.getResponseCode()) ;
                    return ;
                }
                if (skuDetailsList == null) {
                    Toast.makeText(mActivity, mActivity.getString(R.string.msgNotInfo), Toast.LENGTH_LONG).show();
                    return ;
                }
                Log.i(TAG, "listCount=" + skuDetailsList.size());
                for(SkuDetails skuDetails : skuDetailsList) {
                    Log.i(TAG, "\n" + skuDetails.getSku()
                            + "\n" + skuDetails.getTitle()
                            + "\n" + skuDetails.getPrice()
                            + "\n" + skuDetails.getDescription()
                            + "\n" + skuDetails.getFreeTrialPeriod()
                            + "\n" + skuDetails.getIconUrl()
                            + "\n" + skuDetails.getIntroductoryPrice()
                            + "\n" + skuDetails.getIntroductoryPriceAmountMicros()
                            + "\n" + skuDetails.getOriginalPrice()
                            + "\n" + skuDetails.getPriceCurrencyCode()) ;
                }
                mSkuDetails = skuDetailsList ;

            }
        });
    }

    /**
     *
     * {"orderId":"GPA.3309-4529-7908-05842",
     * "packageName":"com.billcoreatech.dream314",
     * "productId":"210318_dream314_monthly",
     * "purchaseTime":1616593760061,
     * "purchaseState":0,
     * "purchaseToken":"nneihaohkgnjojiifcbfdmpg.AO-J1Ow9pKVS60AxVJqKYq_UckNpJ-znNO2ObQLJ0EBKyrAQaatnxxW2DbRWE5vD3cpnS3aPMsKLoCQhwJK8hIOI9ywwGvraN-o3af4njLdq0419SY0TKlg",
     * "autoRenewing":true,
     * "acknowledged":false}
     *
     * @param billingResult
     * @param purchases
     */
    @Override
    public void onPurchasesUpdated(@NonNull BillingResult billingResult, @Nullable List<Purchase> purchases) {

        userinfoDB = FirebaseDatabase.getInstance().getReference("UserInfoDB");
        if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
            Log.i(TAG, "구매 성공>>>" + billingResult.getDebugMessage());
            JSONObject object = null ;
            String pID = "" ;
            String pDate = "" ;
            for(Purchase purchase : purchases) {
                Log.i(TAG, "성공값=" + purchase.getPurchaseToken()) ;
                Log.i(TAG, "성공값=" + purchase.getOriginalJson());
                try {
                    object = new JSONObject(purchase.getOriginalJson());
                    pID = object.getString("purchaseToken");
                    pDate = StringUtil.getDate(object.getLong("purchaseTime"));

                    billinguserBean = new BillinguserBean();
                    billinguserBean.setUserEmail(StringUtil.getEmail(mActivity));
                    billinguserBean.setUserName(StringUtil.getAppDispName(mActivity));
                    billinguserBean.setPurchaseDate(StringUtil.getDate(object.getLong("purchaseTime")));
                    billinguserBean.setPurchaseTerm("1");
                    billinguserBean.setPurchaseStatus(object.getString("purchaseState"));
                    billinguserBean.setOrderId(object.getString("orderId"));
                    billinguserBean.setProductId(object.getString("productId"));
                    billinguserBean.setPurchaseToken(object.getString("purchaseToken"));
                    billinguserBean.setAutoRenewing(object.getBoolean("autoRenewing"));
                    billinguserBean.setAcknowledged(object.getBoolean("acknowledged"));
                    userinfoDB.child(billinguserBean.getUserEmail().replaceAll("[^a-zA-Z0-9]","")+"_")
                            .setValue(billinguserBean);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                Log.i(TAG, "token=" + pID + "" + pDate) ;
                ConsumeParams params = ConsumeParams.newBuilder()
                        .setPurchaseToken(pID)
                        .build() ;
                mBillingClient.consumeAsync(params, mConsumResListnere);
            }
        } else if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.USER_CANCELED) {
            Log.i(TAG, "결제 취소");
        } else {
            Log.i(TAG, "오류 코드=" + billingResult.getResponseCode()) ;
        }
    }
}
