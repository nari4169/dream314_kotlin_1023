package com.billcoreatech.dream314.codeItem;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.billcoreatech.dream314.databinding.CodeitembeanBinding;

import java.util.ArrayList;

public class CodeItemAdapter extends BaseAdapter {

    String TAG = "CodeItemAdapter" ;
    ArrayList<CodeBean> codeBeanArrayList ;
    LayoutInflater inflater;
    CodeitembeanBinding binding ;
    int nListCnt ;

    public CodeItemAdapter(Context context, ArrayList<CodeBean> idata) {
        this.codeBeanArrayList = idata ;
        this.inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return codeBeanArrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return codeBeanArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public void updateReceiptsList(ArrayList<CodeBean> _oData) {
        codeBeanArrayList = _oData;
        nListCnt = codeBeanArrayList.size(); // 배열 사이즈 다시 확인
        this.notifyDataSetChanged(); // 그냥 여기서 하자
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        binding = CodeitembeanBinding.inflate(inflater) ;
        CustomViewHolder holder ;
        if (convertView == null) {
            convertView = binding.getRoot() ;
            holder = new CustomViewHolder();
            holder.txtPrvCd = binding.txtPrvCd ;
            holder.txtPrvNm = binding.txtPrvNm ;
            convertView.setTag(holder) ;
        } else {
            holder = (CustomViewHolder) convertView.getTag();
        }
        holder.txtPrvCd.setText(codeBeanArrayList.get(position).getPrvCd()) ;
        holder.txtPrvNm.setText(codeBeanArrayList.get(position).getPrvNm());
        return convertView;
    }

    public class CustomViewHolder {
        TextView txtPrvCd ;
        TextView txtPrvNm ;
    }
}
