package com.billcoreatech.dream314.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.billcoreatech.dream314.billing.BillinguserBean;

import java.security.MessageDigest;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.SocketHandler;

public class StringUtil {

    static SharedPreferences sp ;
    static SharedPreferences.Editor editor ;
    static String TAG = "StringUtil";

    public static String getAppCode (Context context) {
        sp = context.getSharedPreferences("appCode", context.MODE_PRIVATE);
        return sp.getString("appCode","A001").replaceAll("[^a-zA-Z0-9]","")+"_";
    }

    public static String getAppDispName (Context context) {
        sp = context.getSharedPreferences("appCode", context.MODE_PRIVATE);
        return sp.getString("appDispName","A001");
    }

    public static String getEmail (Context context) {
        sp = context.getSharedPreferences("appCode", context.MODE_PRIVATE);
        return sp.getString("appCode","A001");
    }

    public static String getDate(Long ltime) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        Date nDate = new Date(ltime);
        return sdf.format(nDate);
    }

    public static void setAppCode(Context context, String appCode, String appDispName) {
        if (!"".equals(appCode) && !"".equals(appDispName)) {
            sp = context.getSharedPreferences("appCode", context.MODE_PRIVATE);
            editor = sp.edit();
            editor.putString("appCode", appCode);
            editor.putString("appDispName", appDispName);
            editor.commit();
        }
    }

    public static String makeSHA256(String pwd) {
        try{

            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(pwd.getBytes("UTF-8"));
            StringBuffer hexString = new StringBuffer();

            for (int i = 0; i < hash.length; i++) {
                String hex = Integer.toHexString(0xff & hash[i]);
                if(hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();

        } catch(Exception ex){
            throw new RuntimeException(ex);
        }
    }

    public static boolean isAgree(BillinguserBean billinguserBean) {
        boolean bResult = true ;
        if ("".equals(billinguserBean.getPurchaseDate())) {
            bResult = true ;
        } else if (isTermOver(billinguserBean.getPurchaseDate(), billinguserBean.getPurchaseTerm())) {
            Log.i(TAG, "isTermOver !!!") ;
            bResult = false ;
        }
        return bResult ;
    }

    private static boolean isTermOver(String purchaseDate, String purchaseTerm) {
        if ("".equals(purchaseDate)) {
            return  false ;
        } else {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
            try {
                Date ndate = sdf.parse(purchaseDate);
                Calendar cal = Calendar.getInstance();
                cal.setTime(ndate);
                cal.add(Calendar.MONTH, Integer.parseInt(purchaseTerm));
                long now = System.currentTimeMillis();
                Log.i(TAG, "is = " + now + ">" + cal.getTimeInMillis());
                Log.i(TAG, "is = " + sdf.format(now) + ">" + sdf.format(cal.getTimeInMillis())) ;
                if (now > cal.getTimeInMillis()) {
                    return true ;
                }
            } catch (ParseException e) {
                return false;
            }
        }
        return false ;
    }
}
