package com.billcoreatech.dream314.userManager;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.billcoreatech.dream314.R;
import com.billcoreatech.dream314.codeItem.CodeBean;
import com.billcoreatech.dream314.dataBase.DBHandler;
import com.billcoreatech.dream314.databinding.ActivityUserManagerBinding;
import com.billcoreatech.dream314.util.StringUtil;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class UserManager extends AppCompatActivity {

    String TAG = "UserManager" ;
    ActivityUserManagerBinding binding ;
    String userEmail = "" ;
    String userName = "" ;
    private FirebaseAuth mAuth;
    private GoogleSignInClient mGoogleSignInClient;
    private DatabaseReference mDatabase;
    DatabaseReference codeItem ;
    ArrayList<UserBean> userBeanListArray ;
    UserItemAdapter adapter ;
    DBHandler dbHandler ;
    ArrayList<String> spItem ;
    ArrayList<CodeBean> codeBeans ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityUserManagerBinding.inflate(getLayoutInflater()) ;
        View view = binding.getRoot() ;
        setContentView(view);
        userBeanListArray = new ArrayList<>() ;

        mDatabase = FirebaseDatabase.getInstance().getReference(StringUtil.getAppCode(getApplicationContext()) + "users");
        codeItem = FirebaseDatabase.getInstance().getReference(StringUtil.getAppCode(getApplicationContext()) + "codeItem");

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
        mAuth = FirebaseAuth.getInstance();

        binding.btnSignOut2.setVisibility(View.GONE);

        Intent intent = getIntent();
        userEmail = intent.getStringExtra("userEmail") ;
        userName = intent.getStringExtra("userName") ;

        spItem = new ArrayList<>() ;
        codeBeans = new ArrayList<>() ;

        getCodeData();

        binding.txtEmail.setText(userEmail) ;
        binding.inpUserName.setText(userName);

        binding.btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                writeNewUser(userEmail,
                        binding.inpUserName.getText().toString(),
                        binding.spDeptCd.getSelectedItemId() - 1,
                        binding.spDeptCd1.getSelectedItemId() - 1);
                getDisplayData() ;
            }
        });

        binding.btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isMasterTy()) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(UserManager.this);
                    builder.setTitle(getString(R.string.delete))
                            .setMessage(getString(R.string.msgDelete))
                            .setPositiveButton(getString(R.string.OK), new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                    String[] id = userEmail.split("@") ; // 메일주소 앞에만 사용 @을 사용할 수 없음
                                    mDatabase.child(id[0]).removeValue() ;
                                    Toast.makeText(getApplicationContext(), getString(R.string.msgDeleteCompleted), Toast.LENGTH_LONG).show();
                                    binding.btnSignOut2.performClick() ;

                                }
                            })
                            .setNegativeButton(getString(R.string.cancel), null);
                    AlertDialog dialog = builder.create();
                    dialog.show();
                    dialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(Color.BLUE);
                    dialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(Color.GRAY);
                } else {
                    Toast.makeText(getApplicationContext(), getString(R.string.msgMasterNotDelete), Toast.LENGTH_LONG).show();
                }

            }
        });

        binding.btnSignOut2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signOut() ;
                finish();
            }
        });

        binding.btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        binding.userList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (isMasterTy()) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(UserManager.this);
                    builder.setTitle(getString(R.string.userConfirm))
                            .setMessage(getString(R.string.msgUserConfirm))
                            .setPositiveButton(getString(R.string.OK), new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    String[] id = userBeanListArray.get(position).getUserEmail().split("@") ;
                                    mDatabase.child(id[0]).child("useYn").setValue("Y");
                                    getDisplayData() ;
                                }
                            })
                            .setNegativeButton(getString(R.string.close), new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            })
                            .setNeutralButton(getString(R.string.cancel), new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    String[] id = userBeanListArray.get(position).getUserEmail().split("@") ;
                                    mDatabase.child(id[0]).child("useYn").setValue("N");
                                    getDisplayData() ;
                                }
                            });
                    AlertDialog dialog = builder.create() ;
                    dialog.show();
                    dialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(Color.BLUE);
                    dialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(Color.GRAY);
                    dialog.getButton(DialogInterface.BUTTON_NEUTRAL).setTextColor(Color.RED);

                } else {
                    Toast.makeText(getApplicationContext(), getString(R.string.msgListView), Toast.LENGTH_LONG).show();
                }
            }
        });

        getDisplayData() ;

    }

    private void getCodeData() {

        binding.baseProgressBar.setVisibility(View.VISIBLE);
        codeItem.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                codeBeans.clear();
                spItem.clear();
                spItem.add("");
                for(DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    codeBeans.add(dataSnapshot.getValue(CodeBean.class));
                    spItem.add(dataSnapshot.getValue(CodeBean.class).getPrvNm());
                    Log.i(TAG, dataSnapshot.getValue(CodeBean.class).getPrvNm());
                }
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(UserManager.this,
                        android.R.layout.simple_spinner_item, spItem);
                binding.spDeptCd.setAdapter(adapter);
                binding.spDeptCd1.setAdapter(adapter);

                mDatabase.orderByChild("userEmail").equalTo(userEmail).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for(DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            for(int i=0 ; i < codeBeans.size() ; i++) {
                                if (dataSnapshot.getValue(UserBean.class).getDeptCode() != null
                                        && dataSnapshot.getValue(UserBean.class).getDeptCode().equals(codeBeans.get(i).getPrvCd())) {
                                    binding.spDeptCd.setSelection(i+1);
                                }
                                if (dataSnapshot.getValue(UserBean.class).getDeptCode1() != null
                                        && dataSnapshot.getValue(UserBean.class).getDeptCode1().equals(codeBeans.get(i).getPrvCd())) {
                                    binding.spDeptCd1.setSelection(i+1);
                                }
                            }
                        }
                        binding.baseProgressBar.setVisibility(View.GONE);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        }) ;
    }

    private boolean isMasterTy() {
        boolean bResult = false ;
        /* 2021.03.14 관리자 체크 방법을 변경 했다.
        for(int i=0 ; i < userBeanListArray.size() ; i++) {
            Log.i(TAG, userEmail + "=" + userBeanListArray.get(i).getUserEmail() + ":" + userBeanListArray.get(i).getMasterTy()) ;
            if (userEmail.equals(userBeanListArray.get(i).getUserEmail())) {
                if ("Y".equals(userBeanListArray.get(i).getMasterTy())) {
                    bResult = true;
                    break;
                }
            }
        }*/
        SharedPreferences sp = getSharedPreferences("appCode", MODE_PRIVATE);
        String appCode = sp.getString("appCode", "A001");
        if (userEmail.equals(appCode)) {
            bResult = true ;
        }
        return bResult ;
    }

    public void writeNewUser(String userEmail, String userName, long userDept, long userDept1) {
        Log.i(TAG, "userDept1=" + userDept1);
        UserBean user = new UserBean();
        String[] id = userEmail.split("@") ; // 메일주소 앞에만 사용 @을 사용할 수 없음
        user.setUserEmail(userEmail);
        user.setUserName(userName);
        user.setUserPassword("");
        try {
            user.setUserDept(codeBeans.get((int) userDept).getPrvNm());
            user.setDeptCode(codeBeans.get((int) userDept).getPrvCd());
            if (userDept1 > -1) {
                user.setUserDept1(codeBeans.get((int) userDept1).getPrvNm());
                user.setDeptCode1(codeBeans.get((int) userDept1).getPrvCd());
            } else {
                user.setUserDept1("");
                user.setDeptCode1("");
            }
        } catch (Exception e) {
            user.setUserDept("");
            user.setDeptCode("");
            user.setUserDept1("");
            user.setDeptCode1("");
        }
        if (isMasterTy()) {
            user.setMasterTy("Y");
            user.setUseYn("Y");
        } else {
            user.setMasterTy("N");
            user.setUseYn("N");
        }
        mDatabase.child(id[0]).setValue(user);

        Toast.makeText(getApplicationContext(), getString(R.string.msgSaveCompleted), Toast.LENGTH_LONG).show();
    }

    private void signOut() {
        // Firebase sign out
        mAuth.signOut();

        // Google sign out
        mGoogleSignInClient.signOut().addOnCompleteListener(this,
                new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        finish();
                    }
                });
    }

    public void getDisplayData() {

        binding.baseProgressBar.setVisibility(View.VISIBLE);
        mDatabase.orderByChild("userEmail").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                userBeanListArray.clear();
                for(DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    userBeanListArray.add(dataSnapshot.getValue(UserBean.class));
                    Log.i(TAG, dataSnapshot.getValue(UserBean.class).getUserEmail());
                }
                adapter = new UserItemAdapter(getApplicationContext(), userBeanListArray) ;
                adapter.updateReceiptsList(userBeanListArray);
                binding.userList.setAdapter(adapter);

                for(int i=0 ; i < userBeanListArray.size() ; i++) {
                    if (userBeanListArray.get(i).getUserEmail().contains(userEmail)) {
                        binding.inpUserName.setText(userBeanListArray.get(i).getUserName()) ;
                        break;
                    }
                }
                binding.baseProgressBar.setVisibility(View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        }) ;
    }

}